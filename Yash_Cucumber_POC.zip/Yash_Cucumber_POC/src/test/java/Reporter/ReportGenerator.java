package Reporter;


	public abstract class ReportGenerator {
		
	}
