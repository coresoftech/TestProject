package WebAutomation;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class alert_handling {

	public static void main(String[] args) throws InterruptedException
	{
		WebDriver driver = new FirefoxDriver();
	
		driver.get("http://toolsqa.com/handling-alerts-using-selenium-webdriver/");
		driver.manage().window().maximize();
		Thread.sleep(7000);
	
		 JavascriptExecutor js = (JavascriptExecutor)driver;
	       js.executeScript("scroll(0,350)");
	      
		driver.findElement(By.xpath("//button[@onclick='pushAlert()']")).click();
		
		Alert alert_obj = driver.switchTo().alert();
		
		String simple_alert_titile = alert_obj.getText();
		
		System.out.println(simple_alert_titile);
		Thread.sleep(3000);
		
		//To close the pop-up and for cancel use dismiss
		alert_obj.accept();
		
		//// To handle confirm pop-up
		driver.findElement(By.xpath("//button[contains(.,'Confirm Pop up')]")).click();
		
		Alert alert_obj_confirm = driver.switchTo().alert();
		
		String confirm_alert_textmsg = alert_obj_confirm.getText().toString().trim();
		Thread.sleep(2000);
		System.out.println(confirm_alert_textmsg);
		
		alert_obj_confirm.accept();
		
		
		
		////To handle Prompt pop-up and text yes/no
		driver.findElement(By.xpath("//button[contains(.,'Prompt Pop up')]")).sendKeys("yes");
		driver.findElement(By.xpath("//button[contains(.,'Prompt Pop up')]")).click();
		Alert alert_obj_prompt = driver.switchTo().alert();
		
		String prompt_alert_textmsg = alert_obj_prompt.getText().toString().trim();
		Thread.sleep(2000);
		System.out.println(prompt_alert_textmsg + " Yes/No");
		alert_obj_prompt.sendKeys("sweta");
		
		alert_obj_prompt.accept();
		
		
	}

}
