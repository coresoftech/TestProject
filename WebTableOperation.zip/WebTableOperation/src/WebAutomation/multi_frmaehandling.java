package WebAutomation;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class multi_frmaehandling 
{
	public static void main(String[] args) throws Exception
	{
		WebDriver driver = new FirefoxDriver();
		driver.get("http://toolsqa.com/iframe-practice-page/");
		driver.manage().window().maximize();
		Thread.sleep(3000);
		
		List<WebElement> iframeElements = driver.findElements(By.tagName("iframe"));
		System.out.println("The total number of iframes are " + iframeElements.size());
		
		 JavascriptExecutor js = (JavascriptExecutor)driver;
	       js.executeScript("scroll(0,350)");
		
		//To switch to other frame
		
		/*driver.switchTo().frame(0);
		driver.findElement(By.xpath(".//*[@id='content']/form/fieldset/div[1]/input[1]")).sendKeys("vinayaaaya");
		
		*/
		// to retrive text value
		driver.switchTo().frame("IF2");
		String value = driver.findElement(By.xpath(".//*[@id='post-9']/div/div[1]/h5")).getText();
		System.out.println(value);
		
		
		// to get text value from defalut page
		
		driver.switchTo().defaultContent();
		
		String value1 = driver.findElement(By.xpath(".//*[@id='content']/p[4]")).getText();
		System.out.println(value1);
	}
}
