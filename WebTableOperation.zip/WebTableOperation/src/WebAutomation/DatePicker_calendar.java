package WebAutomation;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class DatePicker_calendar {
	
	static String Date= "21";
	public static void main(String[] args) throws Exception {
		
		WebDriver driver = new FirefoxDriver();
		driver.get("http://seleniumpractise.blogspot.in/2016/08/how-to-handle-calendar-in-selenium.html");
		Thread.sleep(2000);
		
		driver.findElement(By.xpath(".//*[@id='datepicker']")).click();
		
		// To select the table body
		WebElement tablr_obj= driver.findElement(By.xpath(".//*[@id='ui-datepicker-div']/table/tbody"));
		
		List<WebElement> row_obj = tablr_obj.findElements(By.tagName("tr"));
		
		//To print total number of row
		int row_count = row_obj.size();
		
		//To find total no of column on each row
		for(int i=0;i<row_count; i++)
		{
			List<WebElement> column_obj = row_obj.get(i).findElements(By.tagName("td"));
			
			//To print total no of column in a row
			int column_count = column_obj.size();
			for(int j=0;j<column_count;j++)
			{
				System.out.println("Total no of column at row "+i +" is "+column_count);
				String Svalue = column_obj.get(i).getText().toString().trim();
				
				if (Svalue.equals(12)) 
				
				column_obj.get(i).click();
				
				
			}
		}
		
		
		
	}

}

