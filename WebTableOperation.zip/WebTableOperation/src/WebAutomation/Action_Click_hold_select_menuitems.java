package WebAutomation;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Action_Click_hold_select_menuitems
{
	WebDriver driver = new FirefoxDriver();


	
	
	
	

}
