package WebAutomation;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Frame_handling 
{
	public static void main(String[]args) throws Exception 
	{
		WebDriver driver =new FirefoxDriver();
		driver.get("https://rms.yash.com");
		driver.manage().window().maximize();
		Thread.sleep(3000);
		
		//TO click on the edit link
		driver.findElement(By.xpath(".//*[@id='dashboardList']/ul/li[2]/a")).click();
		Thread.sleep(2000);
		
		//To find total no of frames on a page
		List<WebElement> framelist_obj = driver.findElements(By.tagName("iframe"));
		int frame_count = framelist_obj.size();
		System.out.println("Total no frame is "+frame_count);
		//To print all the frame names
		for(int i=0; i<frame_count;i++)
		{
			String name = framelist_obj.get(i).getTagName();
			System.out.println("names of frames is "+name);
			
		}
		
		driver.switchTo().frame(0);
		//To update contact no on contact no textbox 1 and 2
		driver.findElement(By.xpath(".//*[@id='contactNumber1']")).sendKeys("594268976547");
		driver.findElement(By.xpath(".//*[@id='contactNumber2']")).sendKeys("594246890007");
		Thread.sleep(2000);
		
		
		
	}

}
