package WebAutomation;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Auto_It {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		
		 WebDriver driver = new FirefoxDriver();
		   driver.get("http://toolsqa.com/automation-practice-form/");
		   driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		   
		  // maximize browser
		   driver.manage().window().maximize();
		   
		// This will scroll down the page 
		   JavascriptExecutor js = (JavascriptExecutor)driver;
		   js.executeScript("scroll(0,350)");
		   

		   driver.findElement(By.xpath(".//*[@name='photo']")).click();
		    Thread.sleep(2000);
		    
		    Runtime.getRuntime().exec("C:\\Users\\USER\\Desktop\\1.exe");

	}

}
