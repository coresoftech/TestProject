package WebAutomation;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class table_repeate {


	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		
		//To launch the browser
		WebDriver driver = new FirefoxDriver();
		
		//To launch the url
		driver.get("http://materials.springer.com/periodictable#H");
		Thread.sleep(2000);
		driver.manage().window().maximize();
		
		//To select whole table body
		WebElement obj_mytable = driver.findElement(By.xpath(".//*[@id='psTable']"));
		
		//To create the row object list
		List<WebElement> obj_row = obj_mytable.findElements(By.tagName("tr"));
		
		//To count the total no. of row
		int row_count = obj_row.size();
		System.out.println("Total no of row are: "+row_count);
		
		//To create td(column) list on each row
		
		for(int i = 0; i<row_count; i++)
		{
		 List<WebElement> obj_coloun = obj_row.get(i).findElements(By.tagName("td"));
		 
		 int col_count = obj_coloun.size();
		 System.out.println("Total no of column are: "+col_count+" at row is "+i);
		 
		 for(int j=0;j<col_count;j++)
		 {
			 String cell_value = obj_coloun.get(j).getText();
			 System.out.println("Value of Cell at " +i +"," +j + " is : " +cell_value);
		Thread.sleep(1000);
		
		 }
		 
		 
		 
		}
		
	driver.close();	
		
	}
	
	

}
