package WebAutomation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class table_demo 
{
	public static void main(String[] args) {
        // TODO Auto-generated method stub

        WebDriver driver = new FirefoxDriver();
        driver.get("http://materials.springer.com/periodictable#");

        WebElement Mytable = driver.findElement(By.xpath(".//*[@id='psTable']"));

        java.util.List<WebElement> rowtable = Mytable.findElements(By.tagName("tr"));

        int rowcount = rowtable.size();
        System.out.println("total row count" + rowcount);

        //
       

        for (int row = 0; row < rowcount; row++) {

               java.util.List<WebElement> Cellstable = rowtable.get(row).findElements(By.tagName("td"));

               int colncount = Cellstable.size();
              
               //String selenium= Cellstable.get
               System.out.println("Number of cells In Row " + row + " are " + colncount);

               for (int col = 0; col < colncount; col++) {

                     if (Cellstable.get(col).isEnabled()) {

                            String stextvalue = Cellstable.get(col).getText().trim();


                            if (stextvalue.length() > 0) {
                                   boolean b = stextvalue.contains("*");
                                   boolean c = stextvalue.contains("\n");


                                   if (b == false && c==true) {

                                          String[] txtnum = stextvalue.split("\n");
                                          String intvalue = txtnum[0];
                                          String textvalue = txtnum[1];

                                          System.out.println("Int  value at " + row + " and " + col + " is " + intvalue+" and text value is :"+textvalue);
                                          //System.out.println("text value at " + row + " and " + col + " is " + textvalue);

                                   }
                                   else{
                                	   System.out.println(" value at " + row + " and " + col + " is " +stextvalue );
                                	   
                                   }

                            }
                     }
               }

        }

	}

}



