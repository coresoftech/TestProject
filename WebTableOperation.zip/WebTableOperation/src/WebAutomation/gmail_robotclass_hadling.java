package WebAutomation;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

class gmail
{
	public static void gmail_login() throws Exception
	{
		WebDriver driver = new FirefoxDriver();
		driver.get("https://www.google.com/gmail/about/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		
		//To click on sign in button
		driver.findElement(By.xpath("//a[contains(.,'Sign In')]")).click();
		driver.findElement(By.xpath(".//*[@id='identifierId']")).sendKeys(Keys.CLEAR);
		driver.findElement(By.xpath(".//*[@id='identifierId']")).sendKeys("swetran1112");
		driver.findElement(By.xpath("//span[contains(.,'Next')]")).click();
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys(Keys.CLEAR);
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys("sweta0000");
		driver.findElement(By.xpath("//content[contains(.,'Next')]")).click();
		
		String title_name = driver.getTitle();
		
		System.out.println("login successfully"+title_name);
		
	
		driver.findElement(By.xpath("//div[@gh='cm']")).click();
		
		List<WebElement> frame_list_obj = driver.findElements(By.tagName("iframe"));
		int frame_count = frame_list_obj.size();
		System.out.println("total no of frame is "+frame_count);
		for(int i=0;i<frame_count;i++)
		{
			
			int frame_name = frame_list_obj.get(i).hashCode();
			System.out.println("Name of frames are "+frame_name);
			
		}
		
		driver.switchTo().frame("https://clients5.google.com/pagead/drt/dn");
	
		driver.findElement(By.xpath("//*[@id=':o1']")).sendKeys("reply2vinaykr@gmail.com");
		driver.findElement(By.xpath("//*[@id=':nr']")).sendKeys("Excel file");
		driver.findElement(By.xpath("//div[@id=':pf']")).click();
		
		 // Specify the file location with extension
		   StringSelection path_obj = new StringSelection("C:\\Users\\USER\\Desktop\\vi.jpg");
		   StringSelection path_obj1 = new StringSelection("C:\\Users\\USER\\Desktop\\vinay.xlsx");
		   
		   Robot robot_obj = new Robot();
		   Thread.sleep(1000);
		   // Copy to clipboard
	       Toolkit.getDefaultToolkit().getSystemClipboard().setContents(path_obj,null);
	       System.out.println("selection" +path_obj);
	      
		   robot_obj.keyPress(KeyEvent.VK_ENTER);
		   
		   robot_obj.keyRelease(KeyEvent.VK_ENTER);
		   
		   robot_obj.keyPress(KeyEvent.VK_CONTROL);
		   robot_obj.keyPress(KeyEvent.VK_V);
		   
		   robot_obj.keyRelease(KeyEvent.VK_CONTROL);
		   robot_obj.keyRelease(KeyEvent.VK_V);
		   
		   Thread.sleep(2000);
		   robot_obj.keyPress(KeyEvent.VK_ENTER);
		   
		   robot_obj.keyRelease(KeyEvent.VK_ENTER);
			driver.findElement(By.xpath("//div[@id=':pf']")).click();
		   Toolkit.getDefaultToolkit().getSystemClipboard().setContents(path_obj1,null);
	       System.out.println("selection" +path_obj1);
	      
		   
		   //for 2nd file upload
		   robot_obj.keyPress(KeyEvent.VK_ENTER);
		   
		   robot_obj.keyRelease(KeyEvent.VK_ENTER);
		   
		   robot_obj.keyPress(KeyEvent.VK_CONTROL);
		   robot_obj.keyPress(KeyEvent.VK_V);
		   
		   robot_obj.keyRelease(KeyEvent.VK_CONTROL);
		   robot_obj.keyRelease(KeyEvent.VK_V);
		   
		   Thread.sleep(2000);
		   robot_obj.keyPress(KeyEvent.VK_ENTER);
		   
		   robot_obj.keyRelease(KeyEvent.VK_ENTER);
	}
	


}
public class gmail_robotclass_hadling 
{
	public static void main(String[] args) throws Exception
	{
		gmail.gmail_login();
	}
	
}
