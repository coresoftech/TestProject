package WebAutomation;

import java.awt.AWTException;
	import java.awt.Robot;
	import java.awt.Toolkit;
	import java.awt.datatransfer.StringSelection;
	import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
	import org.openqa.selenium.JavascriptExecutor;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.firefox.FirefoxDriver;

	public class robotclass
	{ 
	 
	 public void Authentication () throws AWTException, InterruptedException
	 {   
	   
	  // Start browser
	   WebDriver driver = new FirefoxDriver();
	   driver.get("http://toolsqa.com/automation-practice-form/");
	   driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	   
	  // maximize browser
	   driver.manage().window().maximize();
	   
	// This will scroll down the page 
	   JavascriptExecutor js = (JavascriptExecutor)driver;
	   js.executeScript("scroll(0,350)");
	   

	    //driver.findElement(By.xpath(".//*[@name='photo']")).click();
	    Thread.sleep(2000);
	  /*  
	    try {
			Runtime.getRuntime().exec("C:\\Users\\USER\\Desktop\\fileupload.exe");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
		}*/
	    
	    Thread.sleep(2000);
	    
	    driver.findElement(By.xpath(".//*[@name='photo']")).click();
	    Thread.sleep(2000);
	    
	    
	    // Specify the file location with extension
	   StringSelection path_obj = new StringSelection("C:\\Users\\USER\\Desktop\\vi.jpg");
	   
	     // Copy to clipboard
	   Toolkit.getDefaultToolkit().getSystemClipboard().setContents(path_obj,null);
	   System.out.println("selection" +path_obj);
	   
	  
	   
	   	 
	   System.out.println("Browse button clicked");
	 
	        
	 
	  }
	 
	  public static void robot_fileupload_method() throws Exception{
		   // Create object of Robot class
		   Robot robot_obj = new Robot();
		   Thread.sleep(1000);
		   
		   robot_obj.keyPress(KeyEvent.VK_ENTER);
		   
		   robot_obj.keyRelease(KeyEvent.VK_ENTER);
		   
		   /*robot_obj.keyPress(KeyEvent.VK_DELETE);
		   robot_obj.keyRelease(KeyEvent.VK_DELETE);
		   */
		   robot_obj.keyPress(KeyEvent.VK_CONTROL);
		   robot_obj.keyPress(KeyEvent.VK_V);
		   
		   
		   
		   robot_obj.keyRelease(KeyEvent.VK_CONTROL);
		   robot_obj.keyRelease(KeyEvent.VK_V);
		   

		   robot_obj.keyPress(KeyEvent.VK_ENTER);
		   
		   robot_obj.keyRelease(KeyEvent.VK_ENTER);
		   
		   }
	 public static void main(String[] args) throws Exception
	 {
		 robotclass obj = new robotclass();
		 obj.Authentication();
		 robotclass.robot_fileupload_method();
		 
	 }

	

}
