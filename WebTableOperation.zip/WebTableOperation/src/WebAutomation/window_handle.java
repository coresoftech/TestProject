package WebAutomation;

	import java.util.Set;

	import org.openqa.selenium.By;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.firefox.FirefoxDriver;

	public class window_handle {

	 public static void main(String[] args) throws InterruptedException
	 {
		 
	  try{
		  
	   WebDriver driver1 = new FirefoxDriver();
	   driver1.quit();
	   Thread.sleep(2000);
	   WebDriver driver = new FirefoxDriver();
	   
	   Thread.sleep(2000);
	   driver.get("http://toolsqa.wpengine.com/automation-practice-switch-windows/");

	   Thread.sleep(2000);
	   driver.manage().window().maximize();
	   
	   String parentWindowHandle = driver.getWindowHandle();
	   
	   System.out.println("Parent window's handle -> " + parentWindowHandle);

	   WebElement clickElement = driver.findElement(By.xpath(".//*[@id='button1']")); 

	   for(int i = 0; i < 3; i++)
	   {
	    clickElement.click();
	    Thread.sleep(4000);
	   }


	   Set<String> allWindowHandles = driver.getWindowHandles();

	   for(String handle : allWindowHandles)
	   {
	    System.out.println("Window handle - > " + handle);
	    driver.switchTo().window(handle);
	    Thread.sleep(3000);
	    System.out.println();
	    String childWindowHandle = driver.getWindowHandle();
	    
	    System.out.println("child window's handle -> after switch  " + childWindowHandle);
	   }
	   
	   
	  }catch(Exception e)
	  {

	   System.out.println(e);
	  }
	 }
	}


