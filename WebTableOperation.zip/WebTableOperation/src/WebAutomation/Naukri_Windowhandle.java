package WebAutomation;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Naukri_Windowhandle {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		
		WebDriver driver1 = new FirefoxDriver();
		driver1.quit();
		
		//To launch new browser
		WebDriver driver = new FirefoxDriver();
		
		//To launch naukri.com brwser
		driver.get("https://www.naukri.com/");
		Thread.sleep(2000);
		
		String parentwindow = driver.getWindowHandle();
		System.out.println("ParentWindow is = " +parentwindow);
		
		
		//To click on Jobs links
		driver.findElement(By.xpath("html/body/div[2]/div/ul/li[1]/a/div")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("html/body/div[2]/div/ul/li[3]/a/div")).click();
		
		//To find total no. of window open
		Set<String> no_window = driver.getWindowHandles();
		System.out.println("Total no. of windows open= " +no_window.size());
		
		int window_id_squence=1;
		
		 for(String window_name : no_window)
		   {
		    System.out.println("Window handle - > " + window_name);
		    
		    driver.switchTo().window(window_name);
		    driver.manage().window().maximize();
		    Thread.sleep(3000);
	
		    
		    if(window_id_squence==2){
		    	
		    	driver.close();
		    	System.out.println("Cloing this window.");
		    } 
		    else if(window_id_squence==3){
		    	
		    	String brtext_value = driver.findElement(By.xpath("html/body/div[4]/div/div[1]/h2")).getText();
		    	System.out.println("Text value of the 3rd window is- " +brtext_value);
		    	driver.close();
		    	}
		    
		    else if(window_id_squence==4){
		    	
		    	String brtext1_value = driver.findElement(By.xpath(".//*[@id='browseJobs']")).getText();
		    	System.out.println("Text value of the 4th window is- " +brtext1_value);
		    	driver.close();
		    	}
		    else if(window_id_squence==1){
		    	
		    	
		    	System.out.println("This is the Parent window.");
		    	driver.close();
		    	}
		    
		    window_id_squence=window_id_squence+1;
		   
		   }
		
		
	}

}
