package WebAutomation;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class select_list_dropdown {

	
	public static void main(String[] args) throws Exception {
		
		WebDriver driver = new FirefoxDriver();
		
		driver.get("http://toolsqa.com/automation-practice-form/");
		driver.manage().window().maximize();
		Thread.sleep(4000);
		
		driver.findElement(By.xpath("//input[@name='firstname']")).sendKeys("Sweta");
		
		driver.findElement(By.xpath("//input[@name='lastname']")).sendKeys("Ranjan");
		
		//To find no of type of sex and name
		List<WebElement> sex_obj = driver.findElements(By.name("sex"));
		int sex_count = sex_obj.size();
		System.out.print("total no of sex is "+sex_count);
		
		
		for(int i=0; i<sex_count; i++)
		{
			String sex_name = sex_obj.get(i).getAttribute("value");
			System.out.println("Sex name is "+sex_name);
			
			
				sex_obj.get(i).click();
				Thread.sleep(2000);
					
		}
		
		//To verify the year of experience
		  List<WebElement> exp_obj = driver.findElements(By.name("exp"));
		int exp_count = exp_obj.size();
		System.out.println("Total no of experience are "+exp_count);
		 for(int i=0; i<exp_count; i++)
		 {
			 String exp_value = exp_obj.get(i).getAttribute("value");
			 System.out.println("Total year of experience is "+exp_value);
			
				 exp_obj.get(i).click();
			 Thread.sleep(2000);
		 }
		
		 //To verify continents
		 WebElement continents_obj = driver.findElement(By.id("continents"));
		 Select select_obj = new Select(continents_obj);
		 select_obj.selectByIndex(4);
		 Thread.sleep(2000);
		 select_obj.selectByIndex(3);
		 
		 List<WebElement> continents_list_obj = select_obj.getOptions();
		 
		 
		 for(int i=0;i<continents_list_obj.size(); i++)
		 {
			 String continents_name = continents_list_obj.get(i).getText();
			 select_obj.selectByIndex(i);
			 Thread.sleep(2000);
			 
		 }
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		
		
		
		
		
		
		
		
		
		
		
	}
}
