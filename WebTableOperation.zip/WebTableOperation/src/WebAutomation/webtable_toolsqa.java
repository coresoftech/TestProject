package WebAutomation;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class webtable_toolsqa {

	public static void main(String[] args) throws Exception 
	{
		WebDriver driver = new FirefoxDriver();
		driver.get("http://toolsqa.com/automation-practice-table/");
		
		Thread.sleep(2000);
		
			
		// To select the table body
		WebElement table_obj= driver.findElement(By.xpath(".//*[@id='content']/table"));
		
		List<WebElement> row_obj = table_obj.findElements(By.tagName("tr"));
		
		int row_count = row_obj.size();
		
		for(int i=0; i<row_count; i++)
		{
			//creating column object on each row
			List<WebElement> column_obj = row_obj.get(i).findElements(By.tagName("td"));
			//finding total no of column on each row
			int column_count = column_obj.size();
			
			for(int j=0; j<column_count; j++)
			{
				String Svalue = column_obj.get(j).getText().toString().trim();
				System.out.print(Svalue);
				System.out.print("   ");
			}
			
			System.out.println("   ");
		}
		
	}

}
