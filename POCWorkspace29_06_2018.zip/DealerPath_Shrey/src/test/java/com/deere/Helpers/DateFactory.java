
/* 
 * Project    : DealerPath
 * Script     : DateFactory
 * Author     : Shrishail Baddi
 * Date       : April.03.2018
 * Last Modified On:
 * Modified By :
 */




package com.deere.Helpers;

import java.util.Date;

public class DateFactory {

	public static String format(Date date) {
		if (date == null)
			return "";
		return String.format("%1$tY%1$tm%1$td%1$tH%1$tM%1$tS%1$tL", date);

	}

	/**
	 * 2010-09-10 21:08:17
	 */
	public static String formateYMDHMS(Date date) {
		if (date == null) {
			return "";
		}
		return String.format("%1$tY-%1$tm-%1$td %1$tH:%1$tM:%1$tS", date);
	}

	/**
	 * 2010-09-10
	 */
	public static String formateYMD(Date date) {
		if (date == null) {
			return "";
		}
		return String.format("%1$tY-%1$tm-%1$td", date);
	}


	/**
	 * :09-10
	 */
	public static String formateMD(Date date) {
		if (date == null) {
			return "";
		}
		return String.format("%1$tMM-%1$td", date);
	}


}
