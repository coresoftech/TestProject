package com.deere.Helpers;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;

import org.testng.TestNG;

import com.deere.PageFactory.Login_Page_POF;

/**
 * This method gets unique rackfID's from excel sheet and run the testng suite till the size of rackfID's
 * 
 * @author shrey.choudhary
 * @param strRACFID
 * @createdAt 05-06-2018
 * @throws IOException
 * 
 * @modifyBy 
 * @modifyAt 
 */
public class IterationTest extends BaseClass {
	
	public static void testNgSuite() throws Throwable {
		
			
			HashSet<String> racfIDs = ExcelFactory.uniqueRACFId();
			ArrayList<String> uniqueRackfId = new ArrayList<>(racfIDs);
		   
			LogFactory.info(" Unique number of RACF ID's  >>>>>   " + uniqueRackfId.size() + " " + uniqueRackfId );
			
		//	uniqueRackfId.size()
			try {
					for (int i = 0; i <uniqueRackfId.size(); i++) {
				
						if (ImpersonateUser.impersonateUserSuccess(uniqueRackfId.get(i))) {
						strUserRACFID=uniqueRackfId.get(i);
						System.out.println("Reading excel data");
						
						ExcelFactory.getUserWCMContent();
						
						String strAddtionalTest = ExcelFactory.getflagAddtionalTestCase();
						
						loginPageFactory.verifyImpersonatedUser();
						List<String> suites = new ArrayList<String>();
						
						if (strAddtionalTest.equalsIgnoreCase("Yes")) {	
					
							mapAddtionalTestcase= ExcelFactory.getUserAddtionalTestcases();
							suites.add(strWorkingDir + "\\TestNG_XML\\WCMTestingWithAddtionalTestcases.xml");
							
						}
						else {suites.add(strWorkingDir + "\\TestNG_XML\\WCMContentOnlyTesting.xml");}
					
						TestNG tng = new TestNG();
						tng.setTestSuites(suites);
						tng.run(); // run test suite				
						
						}
						else 
						{
							LogFactory.info("Entered Racf id is incorrect");
						}
					
				}
				
				}catch (Exception e) {
					System.out.println(e.getMessage());
				
					LogFactory.info("Entered Racf id is incorrect");
			}
				
		
	}
}
