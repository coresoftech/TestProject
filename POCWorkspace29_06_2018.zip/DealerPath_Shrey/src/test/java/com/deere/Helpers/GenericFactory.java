
/* 
 * Project    : DealerPath
 * Script     : GenericFactory
 * Author     : Shrishail Baddi
 * Date       : April.08.2018
 * Last Modified On:
 * Modified By :
 */

package com.deere.Helpers;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.StringTokenizer;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

/*import com.deere.PageFactory.Alerts_POF;
import com.deere.PageFactory.Announcements_POF;*/
import com.deere.PageFactory.PortalLeftNavigation_POF;

public class GenericFactory {

	/*
	 * A String is truncated according to reg and stored in a List, and finally
	 * returns a List
	 *
	 * @param str
	 * 
	 * @param reg
	 * 
	 * @return List<String>
	 * 
	 */

	// public static final String DEFAULT_REG = ",";

	public static List<String> splitString(String str, String reg) {

		List<String> strList = new ArrayList<String>();

		if (isNull(str)) {
			return strList;
		}

		StringTokenizer st = new StringTokenizer(str, reg);

		while (st.hasMoreElements()) {

			strList.add(st.nextToken().trim());
		}

		return strList;

	}

	/*
	 * method to determine if a string is null or 0 Yes returns true otherwise false
	 * 
	 * @param str
	 * 
	 * @return boolean
	 */

	public static boolean isNull(String str) {
		if (str == null || str.length() < 1) {
			return true;
		}

		return false;
	}

	// public static WebElement element=null;

	
	
	@SuppressWarnings("null")
	public static void impersonateUser(String strRACFID) {

		WebDriver driver = BaseClass.wbDriver;

		try {

			if (!isNull(strRACFID)) {
	
					if (ValidationFactory.isElementPresent(By.xpath("//b[text() = 'Admin Links']"))) {

						//System.out.println(ValidationFactory.getElementIfPresent(By.xpath("//div[@id='Impersonate_User' and @class ='active']")));
		
						ValidationFactory.getElementIfPresent(By.xpath("//a[text() = 'Impersonate User']")).click();
						LogFactory.info("Clicked Impersonate User link from left navigation.....");
						WaitFactory.waitForPageLoaded();

						LogFactory.info("Enter User RACF ID.....");
						ValidationFactory.getElementIfPresent(By.xpath("//input [@name = 'inputText_AU']")).sendKeys(strRACFID);
						
						LogFactory.info("Click on Search Button.....");
						ValidationFactory.getElementIfPresent(By.xpath("//input [ @name = 'Search']")).click();

						if (ValidationFactory.isElementPresent(By.xpath("//input[@type='radio' and @name='userDNS']"))) {

							LogFactory.info("Select the user.....");
								ValidationFactory.getElementIfPresent(By.xpath("//input[@type='radio' and @name='userDNS']")).click();

							if (ValidationFactory.validateButtonEnable(By.xpath("//input[@type='button' and @name='Impersonate']"))) {

								ValidationFactory.getElementIfPresent(By.xpath("//input[@type='button' and @name='Impersonate']")).click();
								LogFactory.info( "User " + strRACFID + " successfully logged into appllication ");
							}
							else {
									LogFactory.error("Unable to locate the button Impersonate/ it is disabled");
								}	
						}
						else {
							LogFactory.error(strRACFID + " does not exist/No user Found");
						}
					}

				}

			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}
	
	
	public static void endImpersonateOrLogoutUser() {

		WebElement userelement = null;

		try {

			userelement = ValidationFactory.getElementIfPresent(By.xpath("//div[contains (@class,'user-info') and @id ='js-user-info']")); 
						
					if (userelement!=null) {	
						
						userelement.click();
					
						WebElement btnelement =  ValidationFactory.getElementIfPresent(By.xpath("//button[@class='btn' and @onclick='endImpersonate(this)']"));
							
							if (btnelement!=null) {
							
								btnelement.click();
							}
							else {
								ValidationFactory.getElementIfPresent(By.xpath("//button[@class='btn' and @onclick='logoutDealerPath(this)']")).click();
					}
					
				}	
				
		} catch (Exception e) {
			e.printStackTrace();
			LogFactory.info("Unable to logout or impersonate the user");
			Assert.fail("Unable to logout or impersonate the user");
			
		}

	}
	
	
	public static void utilityMenuAdminClick() {
		
		try {
			
			WebElement userelement = null;
			
			userelement = ValidationFactory.getElementIfPresent(By.xpath("//div[contains (@class,'user-info') and @id ='js-user-info']")); 
			
			if (userelement!=null) {	
					
				userelement.click();	
				LogFactory.info("Utility Menu Clicked.....");
				
				ValidationFactory.getElementIfPresent(By.xpath("//a[contains (@href ,'dealerpath.admin')]")).click();
				LogFactory.info("Successfully clicked on Admin Link from utility manu....");
				
			}	
			
		} catch (Exception e) {
			e.printStackTrace();
			LogFactory.info("Unable to click on Admin utility link or Element not found");
			Assert.fail("Unable to click on Admin utility link or Element not found");
			
		}
	}
		
		public static void utilityMenuMyPreferenceClick() {
			
			try {
				
				WebElement userelement = null;
				
				userelement = ValidationFactory.getElementIfPresent(By.xpath("//div[contains (@class,'user-info') and @id ='js-user-info']")); 
				
				if (userelement!=null) {	
						
					userelement.click();	
					LogFactory.info("Utility Menu Clicked.....");
					
					ValidationFactory.getElementIfPresent(By.xpath("//a[@id='preferences']")).click();
					LogFactory.info("Successfully clicked on My Preference Link from utility manu....");
					
				}	
				
			} catch (Exception e) {
				e.getMessage();
				LogFactory.info("Unable to click on My Preference utility link or Element not found");
				Assert.fail("Unable to click on My Preference utility link or Element not found");
				
			}
			
	}
	
		
		public static void utilityMenuSwitchSiteClick() {
			
			try {
				
				WebElement userelement = null;
				
				userelement = ValidationFactory.getElementIfPresent(By.xpath("//div[contains (@class,'user-info') and @id ='js-user-info']")); 
				
				if (userelement!=null) {	
						
					userelement.click();	
					LogFactory.info("Utility Menu Clicked.....");
					
					ValidationFactory.getElementIfPresent(By.xpath("//a[ @id='switch']")).click();
					LogFactory.info("Successfully clicked on switch site Link from utility manu....");
					
				}	
				
			} catch (Exception e) {
				e.printStackTrace();
				LogFactory.info("Unable to click on switch site  utility link or Element not found");
				Assert.fail("Unable to click on switch site utility link or Element not found");
				
			}
			
	}	
	
		
		
		
		
		public static void getUserPrefredLanguage() {
			
			try {
				
				WebElement element  = null;
				
				utilityMenuMyPreferenceClick();
				
				element = ValidationFactory.getElementIfPresent(By.xpath("//select[@id='lang']")); 
				
				if (element!=null) {	
						
					Select  preferedLang = new Select(element);
				
					BaseClass.strUserPrefLang=preferedLang.getFirstSelectedOption().getText();
					ValidationFactory.getElementIfPresent(By.xpath("//button[@id='preference-cancel']")).click();
					LogFactory.info("User current prefered  language is....." + BaseClass.strUserPrefLang);
					
				} else {
						
						BaseClass.strUserPrefLang = "default";
						LogFactory.info("User do not have the option to change the  prefered language, so site is refereing to the default laguage as per the site Region.....");
						ValidationFactory.getElementIfPresent(By.xpath("//button[@id='preference-cancel']")).click();
					}	
			
				
				
			} catch (Exception e) {
				e.getMessage();
				LogFactory.info("Unable to click on switch site  utility link or Element not found");
			//	Assert.fail("Unable to click on switch site utility link or Element not found");
				
			}
			
	}	


		
		/**
         * Method to get the list of Dates by header name for Alert and announcement 
         * @author shrey.choudhary
         * @param header
         * @createdAt 26-05-2018
         * @return
         */
 /*        public static List<String> getListOfDatesByHeaderName(String header) {
                       
        	 			
                    
                         String headerAlert = Alerts_POF.wbelAlertFramePath.findElement(By.xpath("//div[@class='section-header']/h3")).getText();
                         String headerAnnouncement = Announcements_POF.wbelAnnouncementFramePath.findElement(By.xpath("//div[@class='section-header']/h3"))
                                                         .getText();
                         List<String> dateList = new ArrayList<>();
                         if (headerAlert.equalsIgnoreCase(header)) {
                                         List<WebElement> elementsList = Alerts_POF.wbelAlertFramePath.findElements(By.xpath(".//*[@class='list-item-title']"));
                                         for (int i = 0; i < elementsList.size(); i++) {
                                                         String temp = elementsList.get(i).getText();
                                                         dateList.add(GenericFactory.splitString(temp, ":").get(0));
                                         }
                                         return dateList;
                         }
                         else if (headerAnnouncement.equalsIgnoreCase(header)) {
                                         List<WebElement> elementsList = Announcements_POF.wbelAnnouncementFramePath
                                                                         .findElements(By.xpath(".//*[@class='list-item-title']"));
                                         for (int i = 0; i < elementsList.size(); i++) {
                                                         String temp = elementsList.get(i).getText();
                                                         dateList.add(GenericFactory.splitString(temp, ":").get(0));
                                         }
                                         return dateList;
                         } else {
                                         LogFactory.info("Unable to perform the sort order on dates.");
                         }
                         return null;
         }
         
         */
         /**
          * Method to verify the format of dates on the Alert & Announcement portlet
          * @author shrey.choudhary
          * @param header
          * @createdAt 24-05-2018
          * @return
          */
		public static boolean isValidDateFormat(String dateFormat, List<String> listOfDates) {
			boolean isValidFormat = false;
			for(int i=0; i<listOfDates.size();i++) {
	        Date date = null;
	        try {
	            SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
	            date = sdf.parse(listOfDates.get(i));
	            if (!listOfDates.get(i).equals(sdf.format(date))) {
	                date = null;
	            }
	        } catch (ParseException ex) {
	            ex.printStackTrace();
	        
			}
			if(date == null) {
				isValidFormat = false;
				break;
			}else {
				isValidFormat  =true;
			}
			}
			return isValidFormat;
		}
		 
		 /**
         * This Method verifies the order of dates on the Alert & Announcement portlet 
         * @author shrey.choudhary
         * @param header
         * @createdAt 27-05-2018
         * @return
         */
public static boolean verifyDateSortedOrder(List<String> listOfDatesInFrame) {
	List<String> ExpectedlistOfDates = new ArrayList<>();
	ExpectedlistOfDates.addAll(listOfDatesInFrame);
	Collections.sort(ExpectedlistOfDates, new Comparator<String>() {
		DateFormat f = new SimpleDateFormat("dd-MM-yyy");

		@Override
		public int compare(String o1, String o2) {
			try {
				return f.parse(o1).compareTo(f.parse(o2));
			} catch (ParseException e) {
				throw new IllegalArgumentException(e);
			}
		}
	});
	System.out.println("Actual list is : ");
	listOfDatesInFrame.forEach(System.out::println);
	System.out.println("sorted list is : ");
	ExpectedlistOfDates.forEach(System.out::println);
	if (listOfDatesInFrame.equals(ExpectedlistOfDates)) {
		return true;
	}
	return false;
}		


		/**
		 * This method to find the list of webElements from a frame by xpath
		 * @author shrey.choudhary
		 * @param WebElement
		 * @createdAt 27-05-2018
		 * @return List<WebElement>
		 */
		
		public static List<WebElement> getLinksFromFrame(WebElement framePath) {
			List<WebElement> getWebElementsLinks = framePath.findElements(By.tagName("a"));
			List<WebElement> listOfElements = new ArrayList<WebElement>();
			for (int i = 0; i < getWebElementsLinks.size(); i++) {
				listOfElements.add(getWebElementsLinks.get(i));
			}
			return listOfElements;
		}		
		
		public static void createHeaderSection(String header) throws InterruptedException {
		
			ReportFactory.addRoottable();
			ReportFactory.reportSectionName(header);	
			ReportFactory.reporterOutputHeader();
			
		}	
		
		public static void navigateToHomePage() throws InterruptedException {
			
			WebElement userelement = null;		
			userelement = ValidationFactory.getElementIfPresent(By.xpath(".//*[@class='app-title']"));
			
			if (userelement!=null) {	
				LogFactory.info("Navigating to the DealerPath Homepage");
				userelement.click();
			}
		
			
		}		
	
		
		public static List<String> getCheckBoxValues( ) {
			  // List<WebElement> getWebElementsLinks = BaseClass.wbDv.findElements(By.xpath(".//*[@class='checkbox-value']/div/label/div"));
			          
			   List<WebElement> getWebElementsLinks = BaseClass.wbDriver.findElements(By.xpath("//form[@id='productSegmentsForm']/div/div[@class='value']//div"));
			   //System.out.println(getWebElementsLinks.size());
			   //System.out.println(getWebElementsLinks);
			   List<String> listOfElements = new ArrayList<String>();
			   for (int i = 0; i < getWebElementsLinks.size(); i++) {
			    
			   //System.out.println(">>>>>>>>>>>>>>"+getWebElementsLinks.get(i).getText());
			     listOfElements.add(getWebElementsLinks.get(i).getText());
			    
			   }
			   //System.out.println(listOfElements);
			   
			   return listOfElements;
			  }
	
		/**
		  * This method is to capture the screenshot and save them in configured
		  * directory, i.e confi.property or user.dir
		  * @author shrey.choudhary
		  * @createdAt 24-05-2018
		  * @param TCID
		  * @throws Exception
		  * 
		  * @ModifiedBy 
		  * @ModifiedAt 
		  */
		 public static String getScreenshot(String TCID) throws Exception {
		  String filePath = "";

		  if (BaseClass.ENABLE_SCREENSHOT.equalsIgnoreCase("ON")) {
		   BaseClass.strScreenshotDir = FileFolderFactory.createDirectory(BaseClass.strScreenshotDir,
		     "\\Screenshot\\");

		   DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy_HH-mm-ss");
		   Date date = new Date();

		   File scrFile = ((TakesScreenshot) BaseClass.wbDriver).getScreenshotAs(OutputType.FILE);
		   try {
		    // now copy the screenshot to desired location using copyFile //method
		    filePath = BaseClass.strScreenshotDir + TCID + "_" + dateFormat.format(date) + ".png";
		    FileUtils.copyFile(scrFile, new File(filePath));
		   } catch (IOException e) {
		    System.out.println(e.getMessage());
		   }
		  }
		  return filePath;

		 }

		 /*public static String productlistcomparer(String userDefinedProducts, String wcmProducts) {

				String flag = "Fail";
				try {
					
					 * String str1 =
					 * "Agriculture/Ag Equipment,Agriculture/Sprayers & Nutrient Applicators,Construction/Construction,Forestry/Forestry,Hitachi/Mining,Hitachi/Hitachi"
					 * ;
					 * 
					 * String str2 = "Agriculture/Ag Equipment,Construction,Hitachi";
					 

					List<String> userDefinedProductsList = Arrays.asList(userDefinedProducts.split("\\s*,\\s*"));
					List<String> wcmProductsList = Arrays.asList(wcmProducts.split("\\s*,\\s*"));
					
					
					for (int i = 0; i < wcmProductsList.size(); i++) {
					
					String wcmProductsvalue = wcmProductsList.get(i);
					
					for(int k=0;k<userDefinedProductsList.size();k++) {
					
						String userDefinedProductsvalue = userDefinedProductsList.get(k);
						
						if(userDefinedProductsvalue.contains(wcmProductsvalue)) {
						flag = "Pass";
						System.out.println(wcmProductsList.get(i) + " Is Same as " + userDefinedProductsList.get(k));
						LogFactory.info("Product details matched Successfully.");
						break;
						
						
					}
					
				}
							
			}	

						for (int i = 0; i < userDefinedProductsList.size(); i++) {
							
							String userDefinedProductsvalue  = userDefinedProductsList.get(i);

						for (int j = 0; j < wcmProductsList.size(); j++) {
							
							String wcmProductsvalue = wcmProductsList.get(j);

							if (wcmProductsvalue.contains(userDefinedProductsvalue.toString()) || userDefinedProductsvalue.contains(wcmProductsvalue.toString())) {
								flag = "Pass";
								System.out.println (wcmProductsvalue + " Is Same as " + userDefinedProductsvalue);
								LogFactory.info("Product details matched Successfully.");
								break;

							}

						}
						
						}
					 return flag;

				}

				catch (Exception e) {
					flag = "Fail";
					LogFactory.info("Fail");
					// Assert.fail("Fail");

				}
				return flag;

			} */
		 
		 
		 public static boolean productlistcomparer(String userDefinedProducts, String wcmProducts) {

			 boolean flag = false;
				try {
					/*
					 * String str1 =
					 * "Agriculture/Ag Equipment,Agriculture/Sprayers & Nutrient Applicators,Construction/Construction,Forestry/Forestry,Hitachi/Mining,Hitachi/Hitachi"
					 * ;
					 * 
					 * String str2 = "Agriculture/Ag Equipment,Construction,Hitachi";
					 */

					List<String> userDefinedProductsList = Arrays.asList(userDefinedProducts.split("\\s*,\\s*"));
					List<String> wcmProductsList = Arrays.asList(wcmProducts.split("\\s*,\\s*"));
					
					
/*					for (int i = 0; i < wcmProductsList.size(); i++) {
					
					String wcmProductsvalue = wcmProductsList.get(i);
					
					for(int k=0;k<userDefinedProductsList.size();k++) {
					
						String userDefinedProductsvalue = userDefinedProductsList.get(k);
						
						if(userDefinedProductsvalue.contains(wcmProductsvalue)) {
						flag = "Pass";
						System.out.println(wcmProductsList.get(i) + " Is Same as " + userDefinedProductsList.get(k));
						LogFactory.info("Product details matched Successfully.");
						break;
						
						
					}
					
				}
							
			}	*/

						for (int i = 0; i < userDefinedProductsList.size(); i++) {
							
							String userDefinedProductsvalue  = userDefinedProductsList.get(i);

						for (int j = 0; j < wcmProductsList.size(); j++) {
							
							String wcmProductsvalue = wcmProductsList.get(j);

							if (wcmProductsvalue.contains(userDefinedProductsvalue.toString()) || userDefinedProductsvalue.contains(wcmProductsvalue.toString())) {
								flag = true;
								System.out.println (wcmProductsvalue + " Is Same as " + userDefinedProductsvalue);
								LogFactory.info("Product details matched Successfully.");
								break;

							}

						}
						
						}
					 return flag;

				}

				catch (Exception e) {
					flag = false;
					LogFactory.info("Fail");
					// Assert.fail("Fail");

				}
				return flag;

			} 
		 
		 
		 public static WebElement getDeptname(String testdata) {

			  
			  
			  //********* List for active links *****************************
			  List<WebElement> deptListActiveLinks = new ArrayList<WebElement>();
			  

			  for (int i = 0; i < PortalLeftNavigation_POF.ListAllActiveLinks.size(); i++) 
			  {
			   WebElement strdepnameactive = PortalLeftNavigation_POF.ListAllActiveLinks.get(i);
			   deptListActiveLinks.add(strdepnameactive);
			  }
			  
			  //********** List for inactive links ******************************
			  List<WebElement> deptListInactiveLinks = new ArrayList<WebElement>();
			  for (int i = 0; i < PortalLeftNavigation_POF.listAllInactiveLinks.size(); i++) 
			  {
			   WebElement strdepnameinactive = PortalLeftNavigation_POF.listAllInactiveLinks.get(i);
			   deptListInactiveLinks.add(strdepnameinactive);
			  }
			  
			  //*************** compare excel data with active and inactive links***************** 
			  
			  
			  boolean flag1=false;
			  boolean flag2=false;
			  
			  int j = 0;
			  for (; j < deptListActiveLinks.size(); j++) 
			  {
			   //System.out.println(deptList.get(j).getText() + "::" + testdata);
			   
			   if (deptListActiveLinks.get(j).getText().equals(testdata)) 
			   {
			    LogFactory.info("Dept name matching is :"+deptListActiveLinks.get(j).getText());
			    flag1=true;
			    break;
			   }
			   
			   
			  }
			  //System.out.println("Returning :"+deptList.get(j));
			  //return deptListActiveLinks.get(j);
			  
			  if(flag1!=true)
			  {
			   for(int k=0;k<deptListInactiveLinks.size();k++)
			     {
			    System.out.println(deptListInactiveLinks.size());
			    if (deptListInactiveLinks.get(k).getText().equals(testdata)) 
			       {
			     
			     LogFactory.info("Department is inactive :"+deptListInactiveLinks.get(k).getText());
			     flag2=true;
			     break;
			        }
			    
			    
			     }
			  }
			  
			  if(flag1==true)
			  {
			   return deptListActiveLinks.get(j);
			  }
			  else if(flag2==true)
			  {
			   return null;
			  }
			  else {
			   return null;
			  }
			 }	 
		 
	
		 
		 public static void toClickonDept(String deptName)
		  {
		   try{
		  
		   // To clik on 'My DealerPath' arrow
		   WebElement arrowClick = BaseClass.wbDriver.findElement(By.xpath(".//*[@id='left_nav_0']"));
		   
		   
		   //Mouse hover Actions
		   Actions obj = new Actions(BaseClass.wbDriver);
		   obj.moveToElement(arrowClick).build().perform();
		   
		   
		   
		   //To get list of all departments
		   List<WebElement> deptNameList = BaseClass.wbDriver.findElements(By.xpath(".//*[@class='flyout']/li/a"));
		   for(int i=1; i< deptNameList.size(); i++)
		   {
		    String deptNameListValue = deptNameList.get(i).getText().toString().trim();
		 //   System.out.println(deptNameListValue);
		    LogFactory.info("dept Name List Values= " +deptNameListValue);
		    
		    //To click on desire department name given
		    if(deptNameListValue.contains(deptName.trim()))
		    {
		     deptNameList.get(i).click();
		     LogFactory.info("Clicked on desired deparment name. " +deptName);
		     break;
		    }    
		   } 
		    }
		   catch(Exception e)
		   {
		    LogFactory.info("Click on the department. "+e);
		   }
		  } 
		 
		 
		 public static boolean countryListComparison(String UserCountry, String wcmCountry) {

			  boolean flag = false;

			  List<String> wcmCountryList = Arrays.asList(wcmCountry.split("(,)"));
			//  System.out.println(wcmCountryList);

			  List<String> userCountryList = Arrays.asList(UserCountry.split("(,)"));
		//	  System.out.println(userCountryList);

			  try {

			   for (int i = 0; i < wcmCountryList.size(); i++) {
			    for (int j = 0; j < userCountryList.size(); j++) {

			     // System.out.println(wcmCountryList.get(j).concat("/")+"::"+userCountryList.get(i).split("/").trim());
			     if (!wcmCountryList.get(j).contains("/")) {
			      String arr[] = userCountryList.get(j).split("/");
			      if (wcmCountryList.get(i).contains(arr[0])) {
			       flag = true;
			       LogFactory.info("User country contains MRU country");

			      } else {

			       LogFactory.info("User country doesnot contain WCM country");

			      }
			     } else if (!userCountryList.get(j).contains("/")) {
			      if (wcmCountryList.get(i).contains("/")) {
			       flag = false;
			       LogFactory.info("User country doesnot contains MRU country");
			      }
			     }

			     else {
			      System.out.println(wcmCountryList.get(i) + "::" + userCountryList.get(j));
			      if (wcmCountryList.get(i).contains(userCountryList.get(j).trim())) {
			       flag = true;
			       LogFactory.info("User country contains WCM country");

			      } else {

			       LogFactory.info("User country doesnot contain WCM country");

			      }

			     }
			    }
			   }
			  } catch (Exception e) {
			   LogFactory.info("Exception message :-->" + e.getMessage());
			   flag = false;
			  }
			  return flag;
			 }
		 
}
