/* 
 * Project    : DealerPath
 * Script     : Alerts_POF
 * Author     : Neeraja Mantri
 * Date       : May.15.2018
 * Last Modified On:
 * Modified By :
 */

package com.deere.PageFactory;

import javax.xml.xpath.XPath;

import org.apache.commons.logging.Log;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.testng.Assert;

import com.deere.Helpers.LogFactory;
import com.deere.Helpers.ReportFactory;
import com.deere.Helpers.ValidationFactory;

public class Alerts_POF {

	final WebDriver alrtDriver;

	public Alerts_POF(WebDriver driver) {
		this.alrtDriver = driver;

	}

	@FindBy(how = How.XPATH, using = "//div[@class='section warning']")
	static WebElement wbelAlertPortlet;

	@FindBy(how = How.XPATH, using = "//div[@class='section warning']//div[@class='section-header']")
	static WebElement wbelPortletHeader;

	/*
	 * @FindBy (how=How.XPATH, using
	 * ="//h3[@class='section-title'and contains(text(),' DealerPath Alerts')]")
	 * static WebElement alertheader;
	 */

	@FindBy(how = How.XPATH, using = "//span[@class='icon warning']")
	static WebElement wbelWarningImg;
	
	@FindBy(how = How.XPATH, using = ".//*[@id='layoutContainers']/div/div[2]/div[3]/div[2]/section/div/div[2]")
	public static WebElement wbelAlertFramePath;
	
	

	/**
	 * @throws Throwable
	 */
	public static void isAlertPortletPresent() throws Throwable {

		String strFlag = "FAIL";
		String strResult = "Alerts are not displayed";
		try {
			if (ValidationFactory.isElementPresent(wbelAlertPortlet)) {
				strFlag = "PASS";
				strResult = "Alerts are displayed";
			}
			ReportFactory.reporterOutput("TC05_Homepage", "Verify presence of Alert portlet on Home Page", "NA","Alert should be present on homepage", strResult, strFlag);
			
			if (strFlag.equalsIgnoreCase("FAIL") )
			{ 	Assert.assertFalse(true);}

		} catch (Throwable e) {

			ReportFactory.reporterOutput("TC05_Homepage", "Verify presence of Alert portlet on Home Page", "NA","Alert should be present on homepage", e.getMessage().toString(), strFlag);
		}

	}

	/**
	 * @param actualheadertxt
	 * @param TCID
	 * @throws Throwable
	 */
	public static void getAlertPortletHeaderAndText(String strActualHeaderTxt, String strTCID) throws Throwable {

		String strFlag = "FAIL";
		String strResult = "Alert header text is not present";
		try {
			if (ValidationFactory.isElementPresent(wbelPortletHeader)) {

				String strAlertHeaderTxt = wbelPortletHeader.getText();
				if (strAlertHeaderTxt.equals(strActualHeaderTxt)) {
					strFlag = "PASS";
					LogFactory.info("Alert portlet contains header with text");
					strResult = "Alert header text is present :" + strActualHeaderTxt;
				}

			}
			ReportFactory.reporterOutput(strTCID, "Verify alertheadertxt on homepage", "DealerPath Alerts",
					"Alert header text should be present on homepage", strResult, strFlag );

				
		} catch (Throwable e) {

			ReportFactory.reporterOutput(strTCID, "Verify alertheadertxt on homepage", "DealerPath Alerts",
					"Alert header text should be present on homepage", e.getMessage().toString(), strFlag );

		}

	}

	/**
	 * @throws Throwable
	 */
	public static void checkForWarningSignPresentInAlertHeader() throws Throwable

	{
		String strFlag = "FAIL";
		String strResult = "Alert warning sign icon is not displayed";
		try {
			if (ValidationFactory.isElementPresent(wbelWarningImg)) {
				strFlag = "PASS";
				LogFactory.info("Alert warning sign icon is present");
				strResult = "Alert sign is displayed";

			}
			ReportFactory.reporterOutput("TC07_Homepage", "Verify alert warning sign icon on homepage", "warning sign",
					"Alert warning sign icon should be present on homepage", strResult, strFlag );
			
			if (strFlag.equalsIgnoreCase("FAIL") )
			{ 	Assert.assertFalse(true);}

		} catch (Throwable e) {

			ReportFactory.reporterOutput("TC07_Homepage", "Verify alert warning sign icon on homepage", "warning sign",
					"Alert warning sign icon should be present on homepage", e.getMessage().toString(), strFlag );
		}
	}

	/**
	 * @param alertheadertxtprefrdlang
	 * @param TCID
	 * @throws Throwable
	 */
	public static void getAlertHeaderTxtInPreferredLanguage(String strAlertHeaderTxtPrefrdLang, String strTCID)
			throws Throwable {

		String strAlrtHeaderTxtOnHomePage = null;
		String strFlag = "FAIL";
		String strResult = " Alert header Text is not displayed in the user preffered language";
		try {
			if (ValidationFactory.isElementPresent(wbelPortletHeader)) {

				LogFactory.info("Alerts portlet header is present ");
				
				strAlrtHeaderTxtOnHomePage = wbelPortletHeader.getText();
				if (strAlrtHeaderTxtOnHomePage.equals(strAlertHeaderTxtPrefrdLang)) {
					strFlag = "PASS";
					LogFactory.info("Alert is displayed in the user  preffered language with " + strAlrtHeaderTxtOnHomePage + " "
							+ "" + strAlertHeaderTxtPrefrdLang);
					strResult = " Alert header text is displayed in the user preferred language";
				}
				ReportFactory.reporterOutput(strTCID, "Verify alert header text in the user preffered language",
						strAlrtHeaderTxtOnHomePage, "Alert header text should be displayed in the user preffered language",
						strResult, strFlag );
				
				if (strFlag.equalsIgnoreCase("FAIL") )
				{ 	Assert.assertFalse(true);}

			}

		} catch (Throwable e) {

			ReportFactory.reporterOutput(strTCID, "Verify alert header text in the user preffered language",
					strAlrtHeaderTxtOnHomePage, "Alert header text should be displayed in preffered language",
					e.getMessage().toString(), strFlag );
		}

	}

}
