/* 
 * Project    : DealerPath
 * Script     : Homepage_POF
 * Author     : Neeraja Mantri
 * Date       : May.15.2018
 * Last Modified On:
 * Modified By :
 */

package com.deere.PageFactory;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;
import com.deere.Helpers.BaseClass;
import com.deere.Helpers.DateFactory;
import com.deere.Helpers.GenericFactory;
import com.deere.Helpers.LinkFactory;
import com.deere.Helpers.LogFactory;
import com.deere.Helpers.ReportFactory;
import com.deere.Helpers.ValidationFactory;
import com.deere.Helpers.WaitFactory;

/**
 * @author neeraja.mantri
 *
 */
public class testpof {

	static WebDriver HomDriver;
	static SoftAssert softAssert = new SoftAssert();

	public testpof(WebDriver driver) {
		this.HomDriver = driver;

	}

	@FindBy(how = How.XPATH, using = "//div[@class='user-info' ]")
	static WebElement userinfo;

	@FindBy(how = How.XPATH, using = "//h1[@class='app-title']")
	static WebElement titleofhomepage;

	@FindBy(how = How.ID, using = "leftNav")
	static WebElement leftWindow;
	
	@FindBy(how = How.XPATH, using = ".//*[@class='wpthemeFooter']")
	public static WebElement homepageFooterFramePath;
	
	@FindBy(how = How.XPATH, using = "//div[@id='js-notifications']")
	 static WebElement notificationLink;

	 @FindBy(how = How.ID, using = ".//*[@class='list-item']/div")
	 static List<WebElement> wbnotificationList;
	
	 
	 @FindBy(how = How.XPATH, using = ".//*[@id='layoutContainers']/div/div[2]/div[3]/div[2]/section/div/div[2]/div")
	 static WebElement alertIndex;

	 @FindBy(how = How.XPATH, using = ".//*[@id='layoutContainers']/div/div[2]/div[3]/div[3]/section/div/div[2]/div")
	 static WebElement announcementIndex;

	 @FindBy(how = How.XPATH, using = ".//*[@id='layoutContainers']/div/div[2]/div[3]/div[4]/section/div/div[2]/div")
	 static WebElement favoritesIndex;

	 @FindBy(how = How.XPATH, using = ".//*[@id='layoutContainers']/div/div[2]/div[3]/div[1]")
	 static WebElement searchIndex;

	 @FindBy(how = How.XPATH, using = "//div[@class='section-header']/h3")
	 static List<WebElement> sectionHeader;
	 
	 
	 
	/**
	 * @param title
	 * @param TCID
	 * @throws Throwable
	 */
	public static void checkUserLogIntoHomepage(String title, String TCID) throws Throwable {
		String flag = "FAIL";
		String result = "Title is not displayed";
		
		try {
		String strtitlepage = HomDriver.getTitle();
		WaitFactory.waitForPageLoaded();
		LogFactory.info(" Title " + strtitlepage +" is displayed on the homepage");

		

		
		//	if (ValidationFactory.isElementPresent(titleofhomepage)) {
			
			if (testpof.titleofhomepage.isDisplayed()) {
				if (strtitlepage.equalsIgnoreCase(title)) {

					flag = "PASS";
					result = "Title is displayed :" + title;
				}

			}
			ReportFactory.reporterOutput(TCID, "Verify the title is displayed on the homepage", title,
					"Title on homepage should be  " + strtitlepage, result, flag );
			
	/*		if (flag.equalsIgnoreCase("FAIL") )
			{ 	Assert.assertFalse(true);}*/

		}
		catch (Exception e) 
		{

			ReportFactory.reporterOutput(TCID, "Verify the title is displayed on the homepage", title,
			"Title should be displayed on the homepage." ,e.getMessage().toString().substring(0, 125), flag);
		}

	}

	/**
	 * @param welcomemsg
	 * @param TCID
	 * @throws Throwable
	 */
	public static void getWelcomeMessageOnHomepage(String welcomemsg, String TCID) throws Throwable  {
		String flag = "FAIL";
		String result = "Welcome message is not displayed";
		try {
		String strWelcomemsg = userinfo.getText();
		LogFactory.info(" Welcome username :" + strWelcomemsg);
	
			 	
			if (testpof.userinfo.isDisplayed()) 
			{
		//	if (ValidationFactory.isElementPresent(userinfo)) {

				if (strWelcomemsg.equals(welcomemsg)) {
					flag = "PASS";
					result = "Welcome message is displayed :" + welcomemsg;

				}
			}
		
			ReportFactory.reporterOutput(TCID, "Verify welcome message on homepage", strWelcomemsg,
					"Welcome message on homepage should be  " + strWelcomemsg, result, flag );
			
	
			

		} catch (Exception e) {

			ReportFactory.reporterOutput(TCID, "Verify welcome message on homepage", welcomemsg,
					"Welcome message on homepage should be  ",e.getMessage().toString().substring(0, 125), flag );
		}

	}
	
	
	public static void checkorderofportletsdisplayed(String TCID) throws Throwable {
		  String flag = "Fail";
		  String resultPortletOrder="";
try
{
		     // List adding portlet frames
		     ArrayList<WebElement> listPortletframes = new ArrayList<WebElement>();
		     listPortletframes.add(searchIndex);
		     listPortletframes.add(alertIndex);
		     listPortletframes.add(announcementIndex);
		     listPortletframes.add(favoritesIndex);

		     int intListPortletFrameSize = listPortletframes.size();

		     HashMap<Integer, String> headerTxtHomePage = new HashMap<Integer, String>();
		     int intListPageSize = sectionHeader.size();
		     

		     for (int i = 0; i < sectionHeader.size(); i++) {
		      headerTxtHomePage.put(i, sectionHeader.get(i).getText());

		      if (sectionHeader.get(i).getText().contains("My DealerPath Announcements")) {

		       String strAnnouncementHeaderTxt = sectionHeader.get(i).getText();
		       String strAnnouncementTxt = strAnnouncementHeaderTxt.substring(0,strAnnouncementHeaderTxt .lastIndexOf('(') - 1);

		       headerTxtHomePage.put(i, strAnnouncementTxt);
		      }

		     // System.out.println("List of elements :" + sectionHeader.get(i).getText());
		     }
		     HashMap<Integer, String> headerTxtExcelValues = new HashMap<Integer, String>();
		     headerTxtExcelValues .put(0, "DealerPath Alerts");
		     headerTxtExcelValues .put(1, "My DealerPath Announcements");
		     headerTxtExcelValues .put(2, "My DealerPath Favorites");

		     int headerValue =  headerTxtHomePage.size();
		     
		     switch (headerValue) {
		     case 3:
		      resultPortletOrder="Portlets are not displayed as expected";
		      for (int i = 0; i < headerTxtExcelValues.size(); i++) {
		       if (headerTxtExcelValues.get(i).equals( headerTxtHomePage.get(i))) {
		        flag = "Pass";
		        resultPortletOrder="Alerts,Announcements & Favourites portlet order are displayed as expected";
		        LogFactory.info( headerTxtExcelValues.get(i) + " "+"are equal"+" " + headerTxtExcelValues.get(i));
		       } 
		      
		       
		       else {
		        LogFactory.info(headerTxtExcelValues.get(i) + " "+"are not equal" +" "+ headerTxtExcelValues.get(i));
		        flag = "Fail";
		        break;
		       }
		       
		      }
		      LogFactory.info("All the portlets are present in order");
		      ReportFactory.reporterOutput(TCID, "Verify Portlets displayed in order :Alert portlet first,announcement portlet second and favourites portlet last.","NA", "Portlets should be displayed in order :Alert portlet in first,announcement portlet in second and favourites portlet in last",resultPortletOrder, flag );
		      break;
		     case 2:
		      
		      resultPortletOrder="Portlets are not displayed as expected";
		      
		      for (int i = 0; i <  headerTxtHomePage.size(); i++) {
		       
		       String strHeaderTxt =  headerTxtHomePage.get(i);
		       if (strHeaderTxt.equals("DealerPath Alerts")) {
		        flag = "Pass";
		        resultPortletOrder="Alert portlet is displayed first and above announcements & favourites portlet";
		        LogFactory.info("ALerts portlet is displayed first ");
		        ReportFactory.reporterOutput(TCID, "Verify Portlets displayed in order :Alert portlet first,announcement portlet second and favourites portlet last.","NA", "Portlets should be displayed in order :Alert portlet in first,announcement portlet in second and favourites portlet in last",resultPortletOrder, flag );
		        //break;
		       } else if (strHeaderTxt.equals("My DealerPath Announcements")) {
		        flag = "Pass";
		        resultPortletOrder="Announcement portlet is displayed as expected and above favourites portlet or below alerts portlet";
		        LogFactory.info("Announcements portlet is displayed");
		        ReportFactory.reporterOutput(TCID, "Verify Portlets displayed in order :Alert portlet first,announcement portlet second and favourites portlet last.","NA", "Portlets should be displayed in order :Alert portlet in first,announcement portlet in second and favourites portlet in last",resultPortletOrder, flag );
		        break;
		       } else if (strHeaderTxt.equals("My DealerPath Favourites")) {
		        flag = "Pass";
		        LogFactory.info("Favourites portlet is displayed");
		        resultPortletOrder="Favorites portlet is displayed at last";
		        ReportFactory.reporterOutput(TCID, "Verify Portlets displayed in order :Alert portlet first,announcement portlet second and favourites portlet last.","NA", "Portlets should be displayed in order :Alert portlet in first,announcement portlet in second and favourites portlet in last",resultPortletOrder, flag );
		        break;
		       } else {
		        flag = "Fail";    
		        ReportFactory.reporterOutput(TCID, "Verify Portlets displayed in order :Alert portlet first,announcement portlet second and favourites portlet last.","NA", "Portlets should be displayed in order :Alert portlet in first,announcement portlet in second and favourites portlet in last",resultPortletOrder, flag );
		        break;
		       }
		       
		       
		      }
		     
		      break;
		     case 1:
		      
		      for (int i = 0; i <  headerTxtHomePage.size(); i++) {
		       String header =  headerTxtHomePage.get(i);
		       LogFactory.info("Only" +header+ "portlet is present");
		       resultPortletOrder="Only" +header+ "portlet is displayed";
		       flag="Pass";
		      }
		      ReportFactory.reporterOutput(TCID, "Verify order of portlets displayed","NA", "Portlets should be displayed in order :Alert portlet in first,announcement portlet in second and favourites portlet in last",resultPortletOrder, flag );
		     
		      break;
		     default:
		      
		      String resultOrder="No portlets are displayed";
		      LogFactory.info("No portlets are displayed");
		      flag="Fail";
		      ReportFactory.reporterOutput(TCID, "Verify order of portlets displayed","NA", "Portlets should be displayed in order :Alert portlet in first,announcement portlet in second and favourites portlet in last",resultOrder, flag );
		     }
		     
		     
		} catch (Exception e) {
			   ReportFactory.reporterOutput(TCID, "Verify order of portlets displayed","NA", "Portlets should be displayed in order :Alert portlet in first,announcement portlet in second and favourites portlet in last", e.getMessage().toString().substring(0, 125), flag );
}
		 }
	
    /**
    * @author shrey.choudhary
    * @createdAt 22-05-2018
    * @param testData
    * @param TCID
    * @throws Throwable
    * @modifiedAt 22-05-2018
    */
 /*   public static void getDealerPrincipalRole(String strExpectedValue, String TCID) throws Throwable {

           String flag = "FAIL";
           String result = "Dealer is not having dealer principal role";
           try {
                  if (strExpectedValue.equals("NA")) {
                        ReportFactory.reporterOutput(TCID, "Verify Dealer Principal role.", "NA",
                                      "Verify Dealer Principal role.", result, flag);
                  } else {

                        List<String> frameList = new ArrayList<String>();
                        for (int i = 0; i < PortalLeftNavigation_POF.allActiveLinks.size(); i++) {
                               String temp = PortalLeftNavigation_POF.allActiveLinks.get(i).getText();
                               frameList.add(temp);
                        }
                        if (frameList.contains(strExpectedValue)) {
                               flag = "Pass";
                               result = "Dealer is having dealer principal role";
                        }
                        ReportFactory.reporterOutput(TCID, "Verify Dealer Principal role.", "NA",
                                      "Verify Dealer Principal role.", result, flag);
                  }

           } catch (Exception e) {

                  ReportFactory.reporterOutput(TCID, "Verify Dealer Principal role.", "NA", "Verify Dealer Principal role.",
                               e.getMessage().toString().substring(0, 125), flag);
           }
    }*/

    
    /**
     * This method verifies Notification icon is present in user's homepage.
     * 
     * @author shrey.choudhary
     * @createdAt 22-05-2018
     * @param strNotification
     * @param TCID
     * @throws Throwable
     * @modifiedAt 22-05-2018
     */
    public static void verifyNotificationIconOnHomePage(String TCID) throws Throwable {
     String flag = "Fail";
     String result = "Notification link is not applicable/available";
     
     try {
      // if (ValidationFactory.isElementPresent(notificationLink))
    		if (testpof.notificationLink.isDisplayed())	
       {
        result="Notification link is available";
        flag="Pass";
       } 
       
        ReportFactory.reporterOutput(TCID, "Verify notification icon on homepage.", "NA",
          "Verify notification link on homepage.", result, flag);
      
     } catch (Exception e) {
      ReportFactory.reporterOutput(TCID, "Verify notification icon on homepage.", "NA",
        "Verify notification link on homepage.", e.getMessage().toString().substring(0, 125), flag);
     }
    }
    
    
    /**
     * This method compares Notification list with the given input through Excel
     * 
     * @author shrey.choudhary
     * @createdAt 22-05-2018
     * @param strNotification
     * @param TCID
     * @throws Throwable
     * @modifiedAt 22-05-2018
     */
    public static void verifyNotificationsList(String strNotification, String TCID) throws Throwable {
    	
    	String flag = "Fail";
     try {
    	//if (ValidationFactory.isElementPresent(notificationLink))
    	 if (testpof.notificationLink.isDisplayed())	
    	{
    	notificationLink.click();
        List<String> ExpectedData = GenericFactory.splitString(strNotification, ",");
        if (!strNotification.equalsIgnoreCase("NA")) {
       List<WebElement> wbNotification = BaseClass.wbDriver.findElements(By.xpath(".//*[@class='list-item']/div"));
       List<String> notificationList = new ArrayList<String>();
       for (int i = 0; i < wbNotification.size(); i++) {
        String temp = wbNotification.get(i).getText();
        notificationList.add(temp);
       }
       System.out.println(notificationList);
       if (notificationList.equals(ExpectedData))
       {
        flag = "Pass";
       }
       ReportFactory.reporterOutput(TCID, "Verify notification link names on homepage.",
         "Input data is : " + ExpectedData, "Notification list should Match with Input data",
         "Actual data : " + notificationList, flag);
      }
       
    	 
    	 }
    	 else
    	 {
    		 ReportFactory.reporterOutput(TCID, "Verify notification link names on homepage.",
    		         "Notification List", "Notification list should Match with Input data",
    		         "Notification List is not present.", flag);		 
    	 }
     }
    	 
    	 catch (Exception e) 
     {
    		 ReportFactory.reporterOutput(TCID, "Verify notification link names on homepage.", "NA",
        "Verify notification link names on homepage.", e.getMessage().toString().substring(0, 125), flag);
     }
    }
	
    public static void verifyFooterLinksonHomepage(String header,String TCID ) throws Throwable
	  {	
		 /*  // String TCID= "";
		    String flag = "Fail";
		    String result = "Announcement FooterLinks is not showing as per on the UI.";
		    ArrayList<String> StrhomepageFooterList=  new ArrayList<String>();
		    
		    try{

		    	List<WebElement> WeHomepageFooterList = GenericFactory.getLinksFromFrame(homepageFooterFramePath);
		     //List<WebElement> WeHomepageFooterList = BaseClass.wbDv.findElements(By.xpath("html/body/div[15]/footer/div/div/ul/li/a"));
		       for(int i=0;i<WeHomepageFooterList.size();i++)
		       {
		    	   String hearlinktxtvalue = WeHomepageFooterList.get(i).getText().toString().trim();
		    	   StrhomepageFooterList.add(hearlinktxtvalue);
		        }
		      
		      System.out.println(StrhomepageFooterList);
		      
		      // To compare with testdata			      
		      String expectedtestdata = header;
		      String[] StrExpectedtestFooterdataList = expectedtestdata.split(",");
		      
		      for(int i= 0;i<StrhomepageFooterList.size();i++)
		      {			       
		    	  String expectedvalue = StrExpectedtestFooterdataList[i];
		       
		       if(expectedvalue.contains("Switch Site"))
		       {
		    	   flag = "Pass";
		    	   LogFactory.info(expectedvalue + " is present on Footer link");			       }
		       else{ 
		    	   if(StrhomepageFooterList.contains(expectedvalue))
		    	   {
		    		   flag = "Pass";
		    		   LogFactory.info(expectedvalue + " is present on Footer link");
		    	   }
		         else{
		        	 flag = "Fail";
		        	 LogFactory.info(expectedvalue + " is not present on Footer link");
		         }
		       }			       
		      			      
		     //To check system date and Match the date with the 'Copyright � 2017 Deere & Company. All Rights Reserved' link
		      
		     //GenericFactory.isValidDateFormat(dateFormat, listOfDates)
		      String copyrighttxt = BaseClass.wbDv.findElement(By.xpath("html/body/div[15]/footer/div/div[2]/ul/li[3]/a")).getText().toString().trim();
		  			      
		      List<String> copyrightYr = GenericFactory.splitString(copyrighttxt, " ");
		      String copyrightYrValue = copyrightYr.get(2);
		      System.out.println(copyrightYrValue);
		      
		      //getting system DateTime 
		      Date date = new Date();
		      String systemYr = DateFactory.captureYear(date);
		      
		      //getting UI 'copyright' link date
		      if(copyrightYrValue.equals(systemYr))
		      {
		    	  LogFactory.info("Copyright Date is correct as FY yr.");			    	  
		      }
		      else
		      {
		    	  LogFactory.info("Copyright Date is not correct as FY yr.");			    	  
		      }   
		     
		     }
		  }
		      catch (Exception e)
		    {
		     // LogFactory.error("e");
		     //String er = e.getMessage().toString().substring(0, 125).trim();
*/
		       ReportFactory.reporterOutput(TCID, "verify FooterLinks on Homepage", "NA",
		    		   "Announcement FooterLinks is not showing as per on the UI.","" , "Fail");
		      // e.getMessage().toString().substring(0, 125)
		//      }
		     }
    
    
    //***************************************************
    
    public static void PortletLinks(String UserDefinedCountry, String WCMCountry, String UserDefinedProducts,
			String WCMProducts, String RootsiteArea, String Contenttype, String DepartmentName, String level2,
			String Title) throws Throwable
    {
    				boolean flagCC;
    				boolean flagPT;
    				boolean Titleflag = false;
    			//	boolean flagTitle1=false; 
					

					// *************************This is Country and Product Check*****************************
    					LogFactory.info("Verify Country Details.");
						flagCC = GenericFactory.countryListComparison(UserDefinedCountry, WCMCountry);
					 
						LogFactory.info("Verify Product Details");
						flagPT = GenericFactory.productlistcomparer(UserDefinedProducts, WCMProducts);
					
					
				
					
						if (RootsiteArea.contains("AT_Portletlinks")) 
						{

					    LogFactory.info("Site Area Matched Successfully.");
		
					    // *************************This is Department Check*****************************

			LogFactory.info("Verify Department Name");

			WebElement department = GenericFactory.getDeptname(DepartmentName);

			if (department != null)

				department.click();

			else
				GenericFactory.toClickonDept(DepartmentName);

			List<WebElement> actualheadername1 = HomDriver.findElements(By.xpath(".//*[@id='links-target']/div"));
			String headernameflag="Fail";
		 
			for (int j = 0; j < actualheadername1.size(); j++) 
			{
				String temp1 = actualheadername1.get(j).getText().trim();
				String[] lines = temp1.split("\n");
				String headername = lines[0];
				WebElement secondLevel = actualheadername1.get(j);

				if (level2.equals(headername)) 
				{
					headernameflag= "Pass";
					// System.out.println(level2);
					List<WebElement> links = secondLevel.findElements(By.tagName("a"));
				
					//System.out.println(Title);
					/*for (WebElement we1 : links)
					{
						
						if (!(we1.getText().equals(Title)))
						{
							Titleflag=false;
						}
					}*/
					System.out.println(flagCC);
					System.out.println(flagPT);
					System.out.println(Titleflag);
				
					
				
					
					for (WebElement we : links)
					{
						
					
						if (we.getText().equals(Title))
						{
							
							Titleflag =true;
						/*	System.out.println(flagCC);
							
							System.out.println(flagPT);*/
						
							System.out.println(Titleflag); 
				 
					String cextension = we.getAttribute("href");

					String s = cextension.substring(cextension.lastIndexOf("/") + 1);
					// System.out.println(s);
					String s1 = cextension.substring(cextension.lastIndexOf(".") + 1);
					// System.out.println(s1);
					String s2 = s1.substring(0, 4);
					System.out.println(Titleflag);
			
					if(flagCC==true && flagPT==true && Titleflag==true)
					{
						LogFactory.info("Scenario : Country Matched,Product Matched and Title Matched.");
ReportFactory.reporterOutput("Portlet Links_1", "Verify Portlet Links functionality.","WCM Data :"+WCMCountry+":"+WCMProducts+":"+Title, "Country,Product and Title should Match.", "Country Matched,Product Matched and Title Matched.","Pass");	
					}
				
					if(flagCC==true && flagPT==false && Titleflag==true)
					{
						LogFactory.info("Scenario : Country Matched,Product Didn't Match and Title Matched.");
ReportFactory.reporterOutput("Portlet Links_1", "Verify Portlet Links functionality.","WCM Data :"+WCMCountry+":"+WCMProducts+":"+Title, "Country,Product and Title should Match.", "Country Matched,Product Didn't Match and Title Matched.","Fail");					}
					
					if(flagCC==false && flagPT==true && Titleflag==true)
					{
						LogFactory.info("Scenario : Country Didn't Match,Product Matched and Title Matched.");
ReportFactory.reporterOutput("Portlet Links_1", "Verify Portlet Links functionality.","WCM Data :"+WCMCountry+":"+WCMProducts+":"+Title, "Country,Product and Title should Match.", "Country Didn't Match,Product Matched and Title Matched.","Fail");						
					}
					
					if(flagCC==false && flagPT==false && Titleflag==true)
					{
						LogFactory.info("Scenario :Country Didn't Match,Product Didn't Match and Title Matched.");
ReportFactory.reporterOutput("Portlet Links_1", "Verify Portlet Links functionality.","WCM Data :"+WCMCountry+":"+WCMProducts+":"+Title, "Country,Product and Title should Match.", "Country Didn't Match,Product Didn't Match and Title Matched.","Fail");						
					}
					if(flagCC==true &&flagPT==true)
					{
					switch (Contenttype) 
							{
							case "AT-Link":
								if (we.getAttribute("href") != null) 
								{
								int respCode = 200; 
								HttpURLConnection huc = (HttpURLConnection) (new URL(cextension).openConnection());
							    huc.setRequestMethod("HEAD");
							    huc.connect();
							    respCode = huc.getResponseCode();

							    if (respCode <= 400) 
							    {
							    
							    	
							    	 LogFactory.info("This is AT-Link.");
										ReportFactory.reporterOutput("Portlet Links_2",
												" Verify link portlet for content type : " + Contenttype,
												"WCM Maping : Country : " + WCMCountry + "Product Type : "
														+ WCMProducts + "Dept : " + DepartmentName
														+ "Sub Category :  " + level2 + "\n" +
														"Dealer Maping : Country : " + UserDefinedCountry + "Product Type : "
														+ UserDefinedProducts,Title, "Content Type is " + Contenttype, "Pass");
							    }
							    } 
							    

						  
								//}
								else
								{

									LogFactory.info("This is not AT-Link.");
									ReportFactory.reporterOutput("Portlet Links_2",
											" Verify link portlet for content type : " + Contenttype,
											"WCM Maping : Country : " + WCMCountry + "Product Type : "
													+ WCMProducts + "Dept : " + DepartmentName
													+ "Sub Category :  " + level2 + "\n" +															
													"Dealer Maping : Country : " + UserDefinedCountry + "Product Type : "+ UserDefinedProducts,	Title, "Content Type is not " + Contenttype, "Fail");

								}

								break;
							case "AT-Document":
								if (s2.contains("exe") || s2.contains("doc") || s2.contains("pdf")
										|| s2.contains("bmp") || s2.contains("jpg") || s2.contains("jpeg")
										|| s2.contains("html") || s2.contains("log") || s2.contains("png"))
								{
									
 
									LogFactory.info("This is AT-Document.");
									 
									
									ReportFactory.reporterOutput("Portlet Links_2",
											" Verify link portlet for content type : " + Contenttype,
											"WCM Maping : Country : " + WCMCountry + "Product Type : "
													+ WCMProducts + "Dept : " + DepartmentName
													+ "Title :  " + level2 + "\n" +
													"Dealer Maping : Country : " + UserDefinedCountry + "Product Type : "
													+ UserDefinedProducts,Title,"Content Type is " + Contenttype, "Pass");
									 

								}
								
								else
								{
									LogFactory.info("This is not AT-Document.");
								
									ReportFactory.reporterOutput("Portlet Links_2",
											" Verify link portlet for content type : " + Contenttype,
											"WCM Maping : Country : " + WCMCountry + "Product Type : "
													+ WCMProducts + "Dept : " + DepartmentName
													+ "Sub Category :  " + level2 + "\n" +															
													"Dealer Maping : Country : " + UserDefinedCountry + "Product Type : "+ UserDefinedProducts,	Title, "Content Type is not " + Contenttype, "Fail");

									
								}
								break;
							case "AT-Rich Text":

								if (s2.contains("rtf") && (flagCC && flagPT)==true)  {
									
									LogFactory.info("This is AT-RichText.");
									ReportFactory.reporterOutput("Portlet Links_2",
											" Verify link portlet for content type : " + Contenttype,
											"WCM Maping : Country : " + WCMCountry + "Product Type : "
													+ WCMProducts + "Dept : " + DepartmentName
													+ "Title :  " + level2 + "\n" +
													"Dealer Maping : Country : " + UserDefinedCountry + "Product Type : "
													+ UserDefinedProducts,Title,"Content Type is " + Contenttype, "Pass");
									}
								else
								{
									LogFactory.info("This is not AT-RichText.");
									ReportFactory.reporterOutput("Portlet Links_2",
											" Verify link portlet for content type : " + Contenttype,
											"WCM Maping : Country : " + WCMCountry + "Product Type : "
													+ WCMProducts + "Dept : " + DepartmentName
													+ "Sub Category :  " + level2 + "\n" +															
													"Dealer Maping : Country : " + UserDefinedCountry + "Product Type : "+ UserDefinedProducts,	Title, "Content Type is not " + Contenttype, "Fail");

									
								}

								break;
							case "AT-Indexing":
								LogFactory.info("AT-Indexing.");
								ReportFactory.reporterOutput("Portlet Links_2",
										" Verify link portlet for content type : " + Contenttype,
										"WCM Maping : Country : " + WCMCountry + "Product Type : "
												+ WCMProducts + "Dept : " + DepartmentName
												+ "Title :  " + level2 + "\n" +
												"Dealer Maping : Country : " + UserDefinedCountry + "Product Type : "
												+ UserDefinedProducts,Title,"Content Type is " + Contenttype, "Pass");
								break;

				
							}
						
					
						}
						}
					}
				}
			 }
							 if(flagCC==false && flagPT==false && Titleflag==false)
							{
								LogFactory.info("Scenario :Country Didn't Match,Product Didn't Match and Title Didn't Match.");
		ReportFactory.reporterOutput("Portlet Links_1", "Verify Portlet Links functionality.","WCM Data :"+WCMCountry+":"+WCMProducts+":"+Title, "Country,Product and Title should Match.", "Country Didn't Match,Product Didn't Match and Title Didn't Match.","Pass");
							 
							}
							
						if(flagCC==true && flagPT==false && Titleflag==false)
							{
							LogFactory.info("Scenario :Country Matched,Product Didn't Match and Title Didn't Match.");
		ReportFactory.reporterOutput("Portlet Links_1", "Verify Portlet Links functionality.","WCM Data :"+WCMCountry+":"+WCMProducts+":"+Title, "Country,Product and Title should Match.", "Country Matched,Product Didn't Match and Title Didn't Match.","Pass");
						 
							}
						if(flagCC==false && flagPT==true && Titleflag==false)
							{
							LogFactory.info("Scenario :Country Didn't Match,Product Matched. and Title Didn't Match.");
		ReportFactory.reporterOutput("Portlet Links_1", "Verify Portlet Links functionality.","WCM Data :"+WCMCountry+":"+WCMProducts+":"+Title, "Country,Product and Title should Match.", "Country Didn't Match,Product Matched. and Title Didn't Match.","Pass");
						 
							}
							
						 if(flagCC==true && flagPT==true && Titleflag==false)
							{
							LogFactory.info("Scenario :Country Match,Product Match and Title Didn't Match.");				
		ReportFactory.reporterOutput("Portlet Links_1", "Verify Portlet Links functionality.","WCM Data :"+WCMCountry+":"+WCMProducts+":"+Title, "Country,Product and Title should Match.", "Country Match,Product Match and Title Didn't Match.","Fail");
						 
							}	
						 
						
				
				
 					
   
}
							 
						 
						
						 
    }
}


						 
							 


				 
