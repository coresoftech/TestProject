/* 
 * Project    : DealerPath
 * Script     : Homepage_POF
 * Author     : Neeraja Mantri
 * Date       : May.15.2018
 * Last Modified On:
 * Modified By :
 */

package com.deere.PageFactory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;
import java.util.Map.Entry;

import com.deere.Helpers.BaseClass;
import com.deere.Helpers.GenericFactory;
import com.deere.Helpers.LogFactory;
import com.deere.Helpers.ReportFactory;
import com.deere.Helpers.ValidationFactory;
import com.deere.Helpers.WaitFactory;

/**
 * @author neeraja.mantri
 *
 */
public class Homepage_POF {

	static WebDriver HomDriver;

	public Homepage_POF(WebDriver driver) {
		this.HomDriver = driver;

	}

	@FindBy(how = How.XPATH, using = "//div[@class='user-info' ]")
	static WebElement wbelUserInfo;

	@FindBy(how = How.XPATH, using = "//h1[@class='app-title']")
	static WebElement wbelTitleOfHomePage;

	@FindBy(how = How.ID, using = "leftNav")
	static WebElement wbelLeftWindow;
	
	@FindBy(how = How.XPATH, using = ".//*[@class='wpthemeFooter']")
	public static WebElement wbelHomePageFooterFramePath;
	
	@FindBy(how = How.XPATH, using = "//div[@id='js-segments']")
	 static WebElement productsegmenticon;
	
	 @FindBy(how = How.XPATH, using = ".//*[@id='main-header']/div[1]/div/h1")
	 static WebElement homepagepath;

	/**
	 * @param title
	 * @param TCID
	 * @throws Throwable
	 */
	public static void checkUserLogIntoHomepage(String strTitle, String strTCID) throws Throwable {

		String strTitlePage = HomDriver.getTitle();

		WaitFactory.waitForPageLoaded();

		LogFactory.info(" Title " + strTitlePage +" is displayed on the homepage");
		String strFlag = "FAIL";
		String strResult = "Title is not displayed";

		try {
			if (ValidationFactory.isElementPresent(wbelTitleOfHomePage)) {
				if (strTitlePage.equalsIgnoreCase(strTitle)) {

					strFlag = "PASS";
					strResult = "Title is displayed :" + strTitle;
				}

			}
			ReportFactory.reporterOutput(strTCID, "Verify the title is displayed on the homepage", strTitle,
					"Title on homepage should be  " + strTitlePage, strResult, strFlag );
			

		} catch (Throwable e) {

			ReportFactory.reporterOutput(strTCID, "Verify the title is displayed on the homepage", strTitle,
					"Verify the title is displayed on the homepage " + strTitlePage, e.getMessage().toString(), strFlag);
		}

	}

	
	/**
	 * @param welcomemsg
	 * @param TCID
	 * @throws Throwable
	 */
	public static void getWelcomeMessageOnHomepage(String strWelcomemsg, String strTCID) throws Throwable  {
	
		String strWelcomeMsg = wbelUserInfo.getText();
	
		LogFactory.info(" Welcome username :" + strWelcomeMsg);
		String strFlag = "FAIL";
		String strResult = "Welcome message is not displayed";
		
		try {
			if (ValidationFactory.isElementPresent(wbelUserInfo)) {

				if (strWelcomeMsg.equals(strWelcomeMsg)) {
					strFlag = "PASS";
					strResult = "Welcome message is displayed :" + strWelcomeMsg;

				}
			}
		
			ReportFactory.reporterOutput(strTCID, "Verify welcome message on homepage", strWelcomeMsg,
					"Welcome message on homepage should be  " + strWelcomeMsg, strResult, strFlag );
			
			
			

		} catch (Exception e) {

			ReportFactory.reporterOutput(strTCID, "Verify welcome message on homepage", strWelcomeMsg,
					"Welcome message on homepage should be  " + strWelcomeMsg, e.getMessage().toString(), strFlag );
		}

	}
	
    /**
    * @author shrey.choudhary
    * @createdAt 22-05-2018
    * @param testData
    * @param TCID
    * @throws Throwable
    * @modifiedAt 22-05-2018
    */
    public static void getDealerPrincipalRole(String strTestData, String strTCID) throws Throwable {

           String strFlag = "FAIL";
           String strResult = "Dealer is not having dealer principal role";
           try {
                  if (strTestData.equals("NA")) {
                        ReportFactory.reporterOutput(strTCID, "Verify Dealer Principal role.", "NA",
                                      "Verify Dealer Principal role.", strResult, strFlag);
                  } else {

                        List<String> frameList = new ArrayList<String>();
                        for (int i = 0; i < PortalLeftNavigation_POF.ListAllActiveLinks.size(); i++) {
                               String temp = PortalLeftNavigation_POF.ListAllActiveLinks.get(i).getText();
                               frameList.add(temp);
                        }
                        if (frameList.contains(strTestData)) {
                        	strFlag = "Pass";
                        	strResult = "Dealer is having dealer principal role";
                        }
                        ReportFactory.reporterOutput(strTCID, "Verify Dealer Principal role.", "NA",
                                      "Verify Dealer Principal role.", strResult, strFlag);
                  }

           } catch (Throwable e) {

                  ReportFactory.reporterOutput(strTCID, "Verify Dealer Principal role.", "NA", "Verify Dealer Principal role.",
                               e.getMessage().toString(), strFlag);
           }
    }

	
    
	public static ArrayList<String> getLeftWindowLinks() {
		List<WebElement> webElements = wbelLeftWindow.findElements(By.tagName("a"));
		int webElementsSize = webElements.size();
		HashMap<Integer, WebElement> hm = new HashMap<>();
		for (int i = 1; i < webElementsSize; i++) {
			hm.put(i + 1, webElements.get(i));
		}
		List<String> strList = new ArrayList<>();
		for (Entry<Integer, WebElement> entry : hm.entrySet()) {
			strList.add(entry.getValue().getText());
		}
		return (ArrayList<String>) strList;

	}

	public static void verifyleftnavigationwindow(String rawData) throws Throwable {
		ArrayList<String> windowLinks = Homepage_POF.getLeftWindowLinks();

		LogFactory.info(" List of navigation links : " + windowLinks);

		List<String> ExpectedData = GenericFactory.splitString(rawData, ",");
		for (int i = 0; i < ExpectedData.size(); i++) {
			String Actualvalue = windowLinks.get(i).toString().trim();
			if (Actualvalue.equals(ExpectedData.get(i))) {

				LogFactory.info("Actual Value :" + Actualvalue + " || Expected value :" + ExpectedData.get(i));
				// ReportFactory.ReporterOutput("STEP1","Verify_navigationlinks_homepage",
				// "Navigation links" , "Navigation Links should be
				// "+windowLinks,"Navigation links should be displayed","Pass");

			} else {
				LogFactory.info("Actual Value :" + Actualvalue + " || Expected value :" + ExpectedData.get(i));
				ReportFactory.reporterOutput("STEP1", "Verify_navigationlinks_homepage", "Navigation links",
						"Navigation Links should be " + windowLinks, "Navigation links are not displayed", "Fail");
			}

		}
		ReportFactory.reporterOutput("STEP1", "Verify_navigationlinks_homepage", "" + windowLinks,
				"Navigation Links should be " + ExpectedData, "Navigation links are  displayed", "Pass");

	}
	

	
	
/**
 * @author sweta.ranjan
 * @param ContentType
 * @param RootSiteArea
 * @param DeptName
 * @param Title
 * @throws Throwable
 * @modified by Neeraja.mantri
 * @modifiedAt 08-06-2018
 */
public static void chkOrderOfProductSegment(String ContentType, String RootSiteArea, String DeptName, String Title) throws Throwable {
		
		String TCID = "Product Segments";
		String flag = "Fail";
		String result= "Product Segments are not in Sequence as per expected values ";
		WebElement element = null;
		int i=0;
		List<String> expectedDataValue = null;
		List<String> ActualDataFromSite = null;
		List<String> deptnamefromexcel = null;
		
		try{
			
		if (RootSiteArea.equalsIgnoreCase("Homepage") ) {
			
			if(DeptName.equals(""))	{
			
				if (ContentType.contains("AT_ProductType") ) {
					
					WebElement productsegment=WaitFactory.waitForElement(productsegmenticon, HomDriver);
			
					if (productsegment.isEnabled()) 
					{
						WaitFactory.explicitWaitByXpath("//div[@id='js-segments']");
						productsegmenticon.click();
									
						System.out.println("clik ok element. ");
					}

				ActualDataFromSite = GenericFactory.getCheckBoxValues();
								
				List<String> expectedDataFromExcel = GenericFactory.splitString(Title, ",");
				
				if (ActualDataFromSite.equals(expectedDataFromExcel)) {
					LogFactory.info("Product Segments are in Sequence as per expected values ");
					flag="Pass";
					result= "Product Segments are in Sequence as per expected values";
					
				} 
				else {	LogFactory.info("Product Segments are not same as expected. ");
						flag="fail";
						result= "Either Product Segments are not available or they are not in sequence as per expected list";
				}
				ReportFactory.reporterOutput(TCID, "Verify the product types quick link & appropriate/accessible product types are available on Homepage ", 
						" Expected Product List : [" + Title + " ]" ,
						"Product Segment should be available and sequence should be displayed as per expected list ", result + ActualDataFromSite , flag);
			} 
			else {
				LogFactory.info("Content type is not AT_producttype");
				flag="fail";
			}
			
		}
			else if (DeptName.length() > 0) {
				
				if (ContentType.contains("AT_ProductType"))	{
					
					deptnamefromexcel = GenericFactory.splitString(DeptName, ",");
					
					for (int j=0;j<deptnamefromexcel.size();j++){
						WebElement dept = GenericFactory.getDeptname(deptnamefromexcel.get(j));
					
						if(dept!=null)	{
							dept.click();
					
						
							WebElement productsegment=WaitFactory.waitForElement(productsegmenticon, HomDriver);
							
							if (productsegment.isEnabled()) 
							{
								WaitFactory.explicitWaitByXpath("//div[@id='js-segments']");
								productsegmenticon.click();
											
								System.out.println("clik ok element. ");
							}
						
							 ActualDataFromSite = GenericFactory.getCheckBoxValues();
							 expectedDataValue = GenericFactory.splitString(Title, ",");
						
							 if (ActualDataFromSite.equals(expectedDataValue)) {

								flag="Pass";
								LogFactory.info("Product Segments are available and are in the sequence as per expecte list  ");
								result= "Product Segments are available and are in the sequence as per expecte list  ";
								
							 } else {
								LogFactory.info("Product Segments are not available or are not in the sequence as per expecte list  ");
								flag="fail";
								result="Product Segments are not available or are not in the sequence as per expecte list ";
						     }
 							 homepagepath.click();
						}					
				  }				
			 }
			 else {	LogFactory.info("content type is not AT_ProductType ");
					flag="fail";
			 }
				
			 ReportFactory.reporterOutput(TCID, "Verify the product types quick link & appropriate/accessible product types are available on Department Pages [" + DeptName + " ]", 
						 " Expected Product List : [" + Title +" ]" ,
						"Product Segment should be available and sequence should be displayed as per expected list ", result + ActualDataFromSite, flag);	
			}
			
		}
		
		else
			{
			LogFactory.info("Rootsitearea is not homepage");
			flag="fail";
			ReportFactory.reporterOutput(TCID, "Verify the product types quick link & appropriate/accessible product types are available on Homepage", " Expected Product List : [" + Title +" ]" ,
					"Product Segment should be displayed in order as per site", "Rootsitearea is not homepage", flag);
			}
		
	}catch(Exception e)	{
		ReportFactory.reporterOutput(TCID, "Verify the product types quick link & appropriate/accessible product types are available on Homepage", "NA" ,
				"NA", e.getMessage(), "Fail");
		}
}
	



/**
 *  @author sweta.ranjan
 * @param RootSiteArea
 * @param ContentType
 * @param DepartmentName
 * @param expectedData
 * @throws Throwable
 * @modified by Neeraja.mantri
 * @modifiedAt 08-06-2018
 */
public static void verifyOrderofUtilityLinks(String ContentType,String RootSiteArea,String DepartmentName , String Title) throws Throwable
{
 	String TCID= "UtilityLinks";
	String flag = "Fail";
	String result= "Utility Links are not in order ";
	ArrayList<String> actualUtilityLinkLists=null;
	List<String> expectedDataValue = null;
	List<String> deptnamefromexcel=null;
	
	try{
		
		WebElement element = null;

		if (RootSiteArea.equalsIgnoreCase("Homepage")) {	
			
			if(DepartmentName.equals("")){
				
				if  (ContentType.contains("AT_UtilityLinks") ){	
				
					element = ValidationFactory.getElementIfPresent(By.xpath(".//*[@class='primary-caret spr']"));
					if (element.isEnabled()) {
						element.click();

						List<WebElement> utilityLinkLists = BaseClass.wbDriver.findElements(By.xpath(".//*[@class='user-actions']/li/a"));

						actualUtilityLinkLists = new ArrayList<String>();					
						
						for(int j=0; j< utilityLinkLists.size(); j++) {
							String utilityLinkListsNames = utilityLinkLists.get(j).getText().toString().trim();
							actualUtilityLinkLists.add(utilityLinkListsNames);						
						}

						expectedDataValue = GenericFactory.splitString(Title, ",");
						if (actualUtilityLinkLists.equals(expectedDataValue)) {
							
							LogFactory.info("Utility Links are available as expected. ");
							flag = "Pass";
							result= "Utility Links are available as expected and in the same sequence ";
						} 
						else {
							LogFactory.info("Either Utility Links are not available as expected or they are not in same sequence ");
							flag = "Fail";
							result= "Either Utility Links are not available as per expected list or they are not in same sequence";
						}
						ReportFactory.reporterOutput(TCID, "Verify the appropriate utility links are available in the username dropdown for user", " Expected utility links : [" + Title +" ]",
								"The utility links menu for user should contain the links and in the same sequence as per expected list ", result + actualUtilityLinkLists, flag);
					}
				}
			}
			
			else if (DepartmentName.length() > 0) 
			{
				
				if (BaseClass.wbDriver.findElements(By.xpath(".//*[@class='user-actions']/li/a")).size() > 0) {
					
					BaseClass.wbDriver.findElement(By.xpath(".//*[@class='primary-caret spr']")).click();
				}
				
				if  (ContentType.contains("AT_UtilityLinks") ) 
				{	
										
					
					deptnamefromexcel = GenericFactory.splitString(DepartmentName, ",");
					for (int i=0;i<deptnamefromexcel.size();i++)
					{
						
						WebElement dept = GenericFactory.getDeptname(deptnamefromexcel.get(i));
						if(dept!=null)
						{
							dept.click();
							
							element = ValidationFactory.getElementIfPresent(By.xpath(".//*[@class='primary-caret spr']"));
				
							if (element.isEnabled()) 
							{
								
								element.click();
								
								List<WebElement> utilityLinkLists = BaseClass.wbDriver.findElements(By.xpath(".//*[@class='user-actions']/li/a"));
					
								//To store in all utilities link in arraylist
								actualUtilityLinkLists = new ArrayList<String>();					
					
								for(int j=0; j < utilityLinkLists.size(); j++)
								{
									String utilityLinkListsNames = utilityLinkLists.get(j).getText().toString().trim();
									actualUtilityLinkLists.add(utilityLinkListsNames);						
								}
							
								expectedDataValue = GenericFactory.splitString(Title, ",");
								if (actualUtilityLinkLists.equals(expectedDataValue)) {
									LogFactory.info("Utility Links are same as expected list. ");
									flag = "Pass";
									result= "Utility Links are same as expected list.";
								} 
								else {	LogFactory.info("Utility Links are not same as expected. ");
										flag = "Fail";
								}
					
						}
						else {	LogFactory.info("Element is not enabled");
								flag = "Fail";
							}
				
							homepagepath.click();
						}
					}
				}
				else { LogFactory.info("ContentType  is not Utility links ");
				flag = "Fail";
				}
				ReportFactory.reporterOutput(TCID, "Verify the appropriate utility links are available in the username dropdown for user in the Department [ " + DepartmentName + " ]",
						" Expected utility links : [" + Title + " ]",
						"The utility links menu for user should contain the links in the same sequence as per expected list ", result + actualUtilityLinkLists, flag);		
			}
    }
	else {	LogFactory.info("Rootsite area is not homepage ");
			flag = "Fail";
			ReportFactory.reporterOutput(TCID, "verify order of utility links on Homepage", "NA",
					"Utility links should be displayed in order as on site.", result, flag);
	 }
	}catch(Exception e){
		ReportFactory.reporterOutput(TCID, "Verify the appropriate utility links are available in the username dropdown for user", "NA",	"NA", e.getMessage(), "Fail");	
	}
}

}
	
	
	    

