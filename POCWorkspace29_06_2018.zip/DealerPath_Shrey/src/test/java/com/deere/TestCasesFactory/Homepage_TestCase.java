package com.deere.TestCasesFactory;


import java.util.LinkedHashMap;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.deere.Helpers.BaseClass;
import com.deere.Helpers.ExcelFactory;
import com.deere.Helpers.GenericFactory;
import com.deere.Helpers.LogFactory;
import com.deere.Helpers.ReportFactory;
import com.deere.PageFactory.Homepage_POF;

@Test(groups = { "Homepage" })
public class Homepage_TestCase extends BaseClass {

	WebDriver driver;
	static String strExpectedValue;
	static String strTCID;

	@BeforeClass
	public void getReportHeader() throws InterruptedException {
		ReportFactory.tableEnd();
		GenericFactory.createHeaderSection("Home_Page");
	}
	
	

	@Test(priority = 1)
	/* (dependsOnGroups={"Login"}) */

	public void verifyHomepageTitleIsDisplayed() throws Throwable {
		strTCID = "TC02_Homepage";
		strExpectedValue = getExcelDataByTestCaseID(strTCID);

		if (!strExpectedValue.equalsIgnoreCase("None")) {
			LogFactory.beginTestCase("Verify title on the Homepage is displayed");
			homePageFactory.checkUserLogIntoHomepage(strExpectedValue, strTCID);
		}

	}

	@Test(priority = 2)
	public void verifyWelcomeMessageOnHomepage() throws Throwable {

		strTCID = "TC03_Homepage";
		strExpectedValue = getExcelDataByTestCaseID(strTCID);

		if (!strExpectedValue.equalsIgnoreCase("None")) {
			LogFactory.beginTestCase("Verify welcome message on homepage is showing");
			homePageFactory.getWelcomeMessageOnHomepage(strExpectedValue, strTCID);
		}

	}

	@SuppressWarnings("static-access")
	@Test(priority = 3)
	public static void verifyAlertsAreShowingOnHomepage() throws Throwable {

		LogFactory.beginTestCase("Verify presence of Alert portlet on Home Page");
		
		alertPageFactory.isAlertPortletPresent();


	}
	
	
	
	
	
	
	

/*
	
	
	@Test(priority = 1)
	 public static void verifyOrderOfProductSegmentOnHomepage() throws Throwable {
	 
		List<LinkedHashMap> userWCMContent = ExcelFactory.getWCMContentDetails("AT_ProductType");
		
	//	System.out.println(">>>>>>>>>>>>>>>>>" + userWCMContent.size());
		for (int i = 0; i <userWCMContent.size(); i++) 
		{
			//String Contenttype = (String) userWCMContent.get(i).get("ContentType");
			String RootsiteArea = (String) userWCMContent.get(i).get("RootSiteArea").toString().trim();
			String DepartmentName = (String) userWCMContent.get(i).get("DepartmentName").toString().trim();
			String Title = (String) userWCMContent.get(i).get("Title").toString().trim();
			
			
			 LogFactory.beginTestCase("verify Order Of Product Segment On Homepage");
			 
			// ReportFactory.reportSectionName("NM29536_Verify order of produect segments");
			 //ReportFactory.reporterOutputHeader();
			 
			 homePageFactory.chkOrderOfProductSegment("AT_ProductType", RootsiteArea, DepartmentName, Title);
			
		
			
		}
	}
	 
	 @Test(priority = 2)
	   public static void verifyOrderofUtilityLinksOnHomepage() throws Throwable {


		 
		 List<LinkedHashMap> userWCMContent = ExcelFactory.getWCMContentDetails("AT-UtilityLinks");
			
		ystem.out.println(">>>>>>>>>>>>>>>>>" + userWCMContent.size());
			for (int i = 0; i <userWCMContent.size(); i++) 
			{
				//String Contenttype = (String) userWCMContent.get(i).get("ContentType");
				String RootsiteArea = (String) userWCMContent.get(i).get("RootSiteArea").toString().trim();
				String DepartmentName = (String) userWCMContent.get(i).get("DepartmentName").toString().trim();
				String Title = (String) userWCMContent.get(i).get("Title").toString().trim();
				
				
				LogFactory.beginTestCase("verify Order of Utility Links On Homepage");
				//ReportFactory.reportSectionName("Verify order of utility links on homepage");
				
				//ReportFactory.reporterOutputHeader();
				
				homePageFactory.verifyOrderofUtilityLinks("AT_UtilityLinks", RootsiteArea, DepartmentName, Title);
				
						
				
				
			}
		 
		 
	   
	    
	   }
	 
	
	
	/*@Test(priority = 2)
	public void verifyWelcomeMessageOnHomepage() throws Throwable {

		strTCID = "TC03_Homepage";
		strExpectedValue = getExcelDataByTestCaseID(strTCID);

		if (!strExpectedValue.equalsIgnoreCase("None")) {
			LogFactory.beginTestCase("Verify welcome message on homepage is showing");
			homePageFactory.getWelcomeMessageOnHomepage(strExpectedValue, strTCID);
		}

	}

	@SuppressWarnings("static-access")
	@Test(priority = 3)
	public static void verifyAlertsAreShowingOnHomepage() throws Throwable {

		LogFactory.beginTestCase("Verify presence of Alert portlet on Home Page");
		alertPageFactory.isAlertPortletPresent();


	}

	@Test(priority = 4)
	public static void verifyALertHeaderWithTxtIsPresentOnHomepage() throws Throwable {

		strTCID = "TC06_Homepage";
		strExpectedValue = getExcelDataByTestCaseID(strTCID);

		if (!strExpectedValue.equalsIgnoreCase("None")) {
			LogFactory.beginTestCase("Verify alerts headertext on homepage");
			alertPageFactory.getAlertPortletHeaderAndText(strExpectedValue, strTCID);

		}
	}

	@Test(priority = 5)
	public static void verifyWarningSignPresentWithAlertHeaderOnHomepage() throws Throwable {

		LogFactory.beginTestCase("Verify alerts warningsign in alertheader on homepage");
		alertPageFactory.checkForWarningSignPresentInAlertHeader();

	}

	@Test(priority = 6)
	public static void verifyHeaderTxtIsInTheUserPrefferedLanguage() throws Throwable {

		strTCID = "TC08_Homepage";
		strExpectedValue = getExcelDataByTestCaseID(strTCID);
		if (!strExpectedValue.equalsIgnoreCase("None")) {
			LogFactory.beginTestCase("Verify alerts headertext is in the user preferred language on Home Page");
			alertPageFactory.getAlertHeaderTxtInPreferredLanguage(strExpectedValue, strTCID);
		}

	}

	@Test(priority = 7)

	public static void verifyAnnouncementOnTheHomePage() throws Throwable {
		LogFactory.beginTestCase(" Verify presence of Announcements portlet on Home Page");
		strTCID = "TC10_Homepage";
		Announcements_POF.verifyAnnouncementTableOnHomePage(strTCID);
		
	}

	
	
	@Test(priority = 8)
	public static void verifyAnnouncementHeaderTextIsInUserPrefferedLang() throws Throwable {
		strTCID = "TC12_Homepage";
		strExpectedValue = BaseClass.getExcelDataByTestCaseID(strTCID);
		if (!strExpectedValue.equalsIgnoreCase("None")) {
			LogFactory.beginTestCase("Verify announcement header text in the user preffered language");
			Announcements_POF.verifyAnnouncementHeaderTextPrefferedLang(strExpectedValue, strTCID);

		}
	}
	
	@Test(priority = 9)
	public static void verifyAnnouncementContentIsPresent() throws Throwable {
		strTCID = "TC11_Homepage";
		LogFactory.beginTestCase("Verify Announcement content/body is showing");
		Announcements_POF.verifyAnnouncementContentIsPrsent(strTCID);
	}



	*//**
	 * This method verify utility links name should shown in same order as given in test data sheet
	 * 
	 * @author shrey.choudhary
	 * @throws Throwable
	 *//*
	@Test(priority = 10)
	public void verifyUtilityMenuLinksOnHomePage() throws Throwable {
		strTCID = "TC19_Homepage";
		strExpectedValue = BaseClass.getExcelDataByTestCaseID(strTCID);

		if (!strExpectedValue.equalsIgnoreCase("None")) {

			LogFactory.beginTestCase("Verify utility links menu and their order on the home page");
			UtilityLinks_POF.compareUtilityLinksWithTestData(strExpectedValue, strTCID);

		}
	}

	*//**
	 * /**This method verify utility link button name
	 * 
	 * @author shrey.choudhary
	 * @throws Throwable
	 *//*
	@Test(dependsOnMethods = "verifyUtilityMenuLinksOnHomePage", priority = 11)
	public void verifyUtilityButton() throws Throwable {
		strTCID = "TC20_Homepage";
		strExpectedValue = BaseClass.getExcelDataByTestCaseID(strTCID);

		if (!strExpectedValue.equalsIgnoreCase("None")) {
			LogFactory.beginTestCase("Verify Utility Links menu  button Sign-Out/EndImpersonate");
			UtilityLinks_POF.compareUtilityButtonWithTestData(strExpectedValue, strTCID);
		}
	}

	*//**
	 * Script : To Test Favourites on Home Page Author : Archana Gaikwad Date :
	 * April.15.2018
	 * 
	 **//*
	@SuppressWarnings("static-access")
	@Test(priority = 12)
	public void verifyFavouriteHeaderPresentOnHomePage() throws Throwable {
		strTCID = "TC21_Homepage";
		strExpectedValue = BaseClass.getExcelDataByTestCaseID(strTCID);
		if (!strExpectedValue.equalsIgnoreCase("None")) {
			LogFactory.beginTestCase("Verify favourites header is showing on the homepage.");
			favouritesFactory.verifyFavoritesHeaderPresent(strTCID, strExpectedValue);
		
		}
	}

	@SuppressWarnings("static-access")
	@Test(priority = 13)
	public void verifyFavouriteMessageWhenNoFavouritePresent() throws Throwable {
		strTCID = "TC22_Homepage";
		strExpectedValue = BaseClass.getExcelDataByTestCaseID(strTCID);

		if (!strExpectedValue.equalsIgnoreCase("None")) {
			LogFactory.beginTestCase("Verify No Favourites message is displayed on Homepage.");
			favouritesFactory.verifyWhenNoFavouritePresent(strTCID, strExpectedValue);


		}
	}

	@SuppressWarnings("static-access")
	@Test(priority = 14)
	public void verifyFavouriteIconWhenNoFavouritePresent() throws Throwable {
		strTCID = "TC23_Homepage";
		strExpectedValue = BaseClass.getExcelDataByTestCaseID(strTCID);
		if (!strExpectedValue.equalsIgnoreCase("None")) {
			LogFactory.beginTestCase("Verify Favourites Star Icon with message on Homepage");
			favouritesFactory.verifyFavouriteIconWhenNoFavouriteAdded(strTCID, strExpectedValue);

		}

	}
	
	
	@SuppressWarnings("static-access")
	@Test(priority = 15)
	public void verify_homepagequicklink() throws Throwable {
		strTCID = "TC24_Homepage";
		strExpectedValue = BaseClass.getExcelDataByTestCaseID(strTCID);
		if (!strExpectedValue.equalsIgnoreCase("None")) {
			LogFactory.beginTestCase("Verify favourite Quick Links on HomePage");
			favouritesFactory.favouriteQuickLinkOnHomePage(strTCID);

		}
		
	}
	
		@SuppressWarnings("static-access")
		@Test(priority = 16)
		public void verifyQuickLinkFavouritesDropdown() throws Throwable {
			strTCID = "TC25_Homepage";
			strExpectedValue = BaseClass.getExcelDataByTestCaseID(strTCID);
			if (!strExpectedValue.equalsIgnoreCase("None")) {
				LogFactory.beginTestCase("Verify Favourites Quick Links Header");
				favouritesFactory.homePageQuickLinkContent(strTCID,strExpectedValue);

			}
		}
	
	*//**
	  * @author shrey.choudhary
	  * @createdAt 22-05-2018
	  * @throws Throwable
	  * modifiesAt 22-05-2018
	  *//*
	 @Test (priority=17)
	 public void verifyDealerPrincipleRole() throws Throwable
	  {
	  
	   String TCID = "TC26_Homepage";
	   String testData=BaseClass.getExcelDataByTestCaseID(TCID);
		if (!strExpectedValue.equalsIgnoreCase("None")) {
			LogFactory.beginTestCase("Verify Dealer Principal role test case begins");
			 Homepage_POF.getDealerPrincipalRole(testData, TCID);
		}	
	  
	  }
	 

		 
	 @Test(priority=18) 
	 public void verifyProductSegmentsOrder() throws Throwable {
		 
		 strTCID = "TC27_Homepage";
		 
		 strExpectedValue = getExcelDataByTestCaseID(strTCID);
		 if (!strExpectedValue.equalsIgnoreCase("None")) {
				LogFactory.beginTestCase("Verify the available product segments are displayed in order");
				productSegmentFactory.checkOrderOfProductSegment(strExpectedValue, strTCID);
			}
	 
		 
	 }
	 */
	 


	 
	@AfterClass
	public void getReportFooter() throws InterruptedException {
		LogFactory.endTestCase("Home Page Testcases");
		ReportFactory.tableEnd();

	}
	
	@AfterSuite
	
	public void exportToExcel() {
		
		ExcelFactory.writeExcel(); 
	}

}