package javaInterview;

public class Find_minimum_number_of_Lectures {

	public static void main(String[] args)
	{
		int M = 60;  	//No of classess held
		int N = 30;		//No of classes a student attended
		
		

	}

}
