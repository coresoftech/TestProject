package Custome_Properties;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.util.NumberToTextConverter;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtils_tool {
public static Sheet sheet_obj;
public static String get_cell_data(int row, int col, String sheetname) throws IOException{
			 
			 File filename_obj = new File(Constant_Toolsqa.Test_data_path);
			 
				FileInputStream inputstream_obj = new FileInputStream(filename_obj);
				
				@SuppressWarnings("resource")
				XSSFWorkbook workbook_obj = new XSSFWorkbook(inputstream_obj);
				
				//To read sheets in a workbook
				//System.out.println(workbook_obj.getNumberOfSheets());
			
				Sheet sheet_obj = workbook_obj.getSheet(sheetname);
				
				Cell cellValue = sheet_obj.getRow(row).getCell(col);
	        	
	        	if(cellValue.getCellType() == Cell.CELL_TYPE_NUMERIC) {
	        	    String str = NumberToTextConverter.toText(cellValue.getNumericCellValue());
	        	   
	        	    return str;

	        	}
	        	else{
	        	String str = sheet_obj.getRow(row).getCell(col).getStringCellValue().toString();
	           
	            return str;
				
			
		 }
 		

}

			

}


