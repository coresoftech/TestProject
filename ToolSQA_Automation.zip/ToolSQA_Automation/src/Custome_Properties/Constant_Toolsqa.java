package Custome_Properties;

import org.apache.poi.ss.usermodel.Sheet;
import org.openqa.selenium.WebDriver;

public class Constant_Toolsqa {
	
	
public static WebDriver driver= null;
public static String URL = "http://toolsqa.com/";

public static final String Test_data_path = "C:\\Users\\USER\\Desktop\\data.xlsx";

public static final String test_sheetname = "Automation_practice_form";
}
