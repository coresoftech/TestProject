package TestCase_Automation_Practice_Form;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import Custome_Properties.Constant_Toolsqa;

public class Interview {

	      //URL - http://toolsqa.com/
//		Under Demo Sites- Automation Practice Form 
//		fill form and upload file using robot class.
//		Print all list item also

	public static void main(String[] args) throws Exception{
		WebDriver driver= new FirefoxDriver();
		driver.manage().window().maximize();
		//driver.get("http://toolsqa.com/");
		driver.get("http://toolsqa.com/automation-practice-form/");
		
	Thread.sleep(3000);
	driver.findElement(By.xpath("//input[@id='profession-0']")).click();
	
	
	
	List<WebElement> obj= driver.findElements(By.xpath(".//input[@name='profession']"));
	
	System.out.println(obj.size());
	
	
	for(int i=0 ;i<obj.size();i++){
		
		System.out.println(obj.get(i).getAttribute("value"));
	}
	
	obj.get(1).click();
	
	
	List<WebElement> automation_list_menu_obj = driver.findElements(By.xpath(".//input[@name='tool']"));
	int automation_list_menu_count = automation_list_menu_obj.size();
	
	System.out.println(automation_list_menu_count);
	
	//To print the names of automation tools
	for(int i=0;i<automation_list_menu_count;i++)
	{
		
	 automation_list_menu_obj.get(i).click();
	 String sname = automation_list_menu_obj.get(i).getAttribute("value");
	 System.out.println(sname);
		
	}
	}
	


	
	
}
