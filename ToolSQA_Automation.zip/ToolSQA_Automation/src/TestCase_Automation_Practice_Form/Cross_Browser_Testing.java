package TestCase_Automation_Practice_Form;

import java.io.IOException;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import Action_Automation_practice_form.Action_Automation_Practice_form;
import Action_DemoSite_list_name.Demo_Site_Link;
import Action_setup_Launch.Action_Login;
import Custome_Properties.ExcelUtils_tool;

public class Cross_Browser_Testing {
	
	
	 @Test(priority = 1)
		
public static void Autmate_page() throws IOException, Exception{

	String Fname = ExcelUtils_tool.get_cell_data(1, 0, "Automation_practice_form");
	String Lname = ExcelUtils_tool.get_cell_data(1, 1, "Automation_practice_form");
	String sextype = ExcelUtils_tool.get_cell_data(1, 2, "Automation_practice_form");
	String date = ExcelUtils_tool.get_cell_data(1, 3, "Automation_practice_form");
	String automation_tool = ExcelUtils_tool.get_cell_data(1, 5, "Automation_practice_form");
		
	//Action_Login.quit_driver();
	//	Action_Login.setup_launch();
		Demo_Site_Link.click_demosite();
	
		Demo_Site_Link.print_demolink_list_name();
		
		Action_Automation_Practice_form.click_automation_link();
		Thread.sleep(8000);
		Action_Automation_Practice_form.sendkeys_First_last_name(Fname, Lname);
		Action_Automation_Practice_form.select_sex_type(sextype);	
		Action_Automation_Practice_form.select_Yearofexperience_type("2");
		Action_Automation_Practice_form.sendkeys_date(date);
		Action_Automation_Practice_form.select_profession();
		Action_Automation_Practice_form.select_automation_tool(automation_tool);
		
		Action_Automation_Practice_form.select_continents();
		
		Action_Automation_Practice_form.select_selenium_commands();
		Action_Automation_Practice_form.click_on_submit_button();
		
	}

}


