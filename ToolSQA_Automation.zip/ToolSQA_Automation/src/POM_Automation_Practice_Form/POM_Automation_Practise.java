package POM_Automation_Practice_Form;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class POM_Automation_Practise
{
	private static WebElement element =null;
	private static List<WebElement> element1 =null;
	
	public static WebElement text_headline(WebDriver driver)
	{
		element = driver.findElement(By.xpath(".//*[@id='content']/h1"));
		return element;
	}
	
	public static WebElement automation_practise_link(WebDriver driver)
	{
		element = driver.findElement(By.xpath(".//*[@id='primary-menu']/li[8]/ul/li[3]/a/span[1]/span/span"));
		return element;
	}
	
	public static WebElement textbox_firstname(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//input[@name='firstname']"));
		return element;
	}
	
	public static WebElement textbox_lastname(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//input[@name='lastname']"));
		return element;
	}
	public static List<WebElement> rb_button_sex(WebDriver driver)
	{
		 element1 = driver.findElements(By.name("sex"));
		return element1;
	}
	
	public static List<WebElement> rb_button_yearofexperience(WebDriver driver)
	{
		 element1 = driver.findElements(By.name("exp"));
		return element1;
	}
	
	public static WebElement textbox_date(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//input[@id='datepicker']"));
		return element;
	}
	
	
	
	public static WebElement wb_click_image(WebDriver driver)
	{
		element = driver.findElement(By.xpath(".//*[@id='photo']"));
		return element;
	}

	
	public static List<WebElement> wb_checkbox_profession(WebDriver driver)
	{
		 element1 = driver.findElements(By.xpath(".//input[@name='profession']"));
		return element1;
	}
	
	public static List<WebElement> wb_checkbox_automation_tool(WebDriver driver)
	{
		 element1 = driver.findElements(By.xpath(".//input[@name='tool']"));
		return element1;
	}
	
	
	
	public static WebElement select_menu_continents(WebDriver driver)
	{
		element = driver.findElement(By.id("continents"));
		return element;
	}
	
	public static List<WebElement> listlink_selenium_commands(WebDriver driver)
	{
		 element1 = driver.findElements(By.xpath(".//*[@id='selenium_commands']/option"));
		return element1;
	}
	
	public static WebElement button_submitbutton(WebDriver driver)
	{
		element = driver.findElement(By.xpath(".//*[@id='submit']"));
		return element;
	}

	
}





















	