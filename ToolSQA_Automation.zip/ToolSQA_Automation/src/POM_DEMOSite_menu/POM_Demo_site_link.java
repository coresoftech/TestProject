package POM_DEMOSite_menu;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class POM_Demo_site_link {
	
	
	private static WebElement element= null;
	private static List<WebElement> element1= null;
	
	
	public static WebElement Demo_link(WebDriver driver){
		
		element = driver.findElement(By.xpath(".//*[@id='primary-menu']/li[8]/a"));
		return element;
	}
	
	
	
	public static List<WebElement> Demo_link_list(WebDriver driver)
	{
		element1 = driver.findElements(By.xpath(".//*[@id='primary-menu']/li[8]/ul/li/a/span[1]/span/span"));
		return element1;
		
	}

	
	
}
