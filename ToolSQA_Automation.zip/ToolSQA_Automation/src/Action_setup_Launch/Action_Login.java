package Action_setup_Launch;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import Custome_Properties.Constant_Toolsqa;

public class Action_Login {
	@Test
	@Parameters({"pbrowser"})
	
	public static void setup_launch(String pbrowser)
	{try	
	{
       if (pbrowser.equalsIgnoreCase("firefox")){
	
		Constant_Toolsqa.driver= new FirefoxDriver();
		System.out.println("Firefoxlaunch");
		
        }

   else  if(pbrowser.equalsIgnoreCase("Internet")){
	   System.setProperty("webdriver.ie.driver", "E:\\Selenium\\Driver\\IEDriverServer_x64_2.53.0\\IEDriverServer.exe");
	   
	   Constant_Toolsqa.driver = new InternetExplorerDriver();  
		System.out.println("IElaunch");
	   
   }
   else  if(pbrowser.equalsIgnoreCase("Crome")){
	   System.setProperty("webdriver.chrome.driver", "E:\\Selenium\\Driver\\chromedriver_win32 (1)\\chromedriver.exe");
	   ChromeOptions opt = new ChromeOptions();
	   opt.addArguments("disable-extensions");
	   opt.addArguments("--start-maximized");
	   System.out.println("Cromelaunch");
	   Constant_Toolsqa.driver = new ChromeDriver(); 
	   System.out.println("Cromelaunch");
	   
   }
       
		Constant_Toolsqa.driver.get(Constant_Toolsqa.URL);
		Constant_Toolsqa.driver.manage().window().maximize();
		Constant_Toolsqa.driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		
	}catch(Exception e)
	{
		System.out.println("Unable to launch the browser and url. " +e);
	}
	}

	
	/*public static void quit_driver(){
		
		Constant_Toolsqa.driver.close();
		
	}*/
}
