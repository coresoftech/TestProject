package Action_DemoSite_list_name;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import Custome_Properties.Constant_Toolsqa;
import POM_DEMOSite_menu.POM_Demo_site_link;

public class Demo_Site_Link {
	
	public static void click_demosite()
	
	
	{
		//POM_Demo_site_link.Demo_link(Constant_Toolsqa.driver)
		Actions Action_obj= new Actions(Constant_Toolsqa.driver);
		
		Action_obj.moveToElement(POM_Demo_site_link.Demo_link(Constant_Toolsqa.driver)).build().perform();
		
		
		
	}

	
	public static void print_demolink_list_name()
	
	
	{
		List<WebElement> list_name_obj = POM_Demo_site_link.Demo_link_list(Constant_Toolsqa.driver);
		
		int List_count = list_name_obj.size();
		
		for (int i=0;i<List_count;i++)
		{
			String demolink_name = list_name_obj.get(i).getText().toString().trim();
			System.out.println("Demo list names are "+demolink_name);
			
		}
		
		
		
	}

	
}
