package Action_Automation_practice_form;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import Custome_Properties.Constant_Toolsqa;
import POM_Automation_Practice_Form.POM_Automation_Practise;

public class Action_Automation_Practice_form
{
	//CLICK ON LOGIN
	public static void click_automation_link()
	{
		POM_Automation_Practise.automation_practise_link(Constant_Toolsqa.driver).click();
	}
	
	//SENDKEYS TO LOGIN
	public static void sendkeys_First_last_name(String Fname, String Lname)
	{
		POM_Automation_Practise.textbox_firstname(Constant_Toolsqa.driver).sendKeys(Fname);
		POM_Automation_Practise.textbox_lastname(Constant_Toolsqa.driver).sendKeys(Lname);
		System.out.println("Enter first name and last name is "+Fname+" and "+Lname);
		
	}
	
	//SEX TYPE
	public static void select_sex_type(String Sextype)
	{
		List<WebElement> sex_button_list_obj = POM_Automation_Practise.rb_button_sex(Constant_Toolsqa.driver);
		
		int sex_count = sex_button_list_obj.size();
		//to print the names of sextype
		for(int i=0;i<sex_count;i++)
		{
			String sex_name = sex_button_list_obj.get(i).getAttribute("value").toString().trim();
			System.out.println("Types of sex are "+sex_name);
			if(sex_name.contains(Sextype))
			{
				sex_button_list_obj.get(i).click();
				System.out.println("Selected Sex type is "+Sextype);
				
			}
		}	
		
	}
	
	//YEAR OF EXPERIENCE
	public static void select_Yearofexperience_type(String Yr_exp)
	{
		List<WebElement> yearofexperience_list_obj = POM_Automation_Practise.rb_button_yearofexperience(Constant_Toolsqa.driver);
		
		int yearofexperience_count = yearofexperience_list_obj.size();
		//To print the total no of yearofexperience
		for(int i=0;i<yearofexperience_count;i++)
		{
			String yearofexperience_numbers = yearofexperience_list_obj.get(i).getAttribute("value").toString().trim();
			System.out.println("Total no of yearofexperience_are "+yearofexperience_numbers);
			if(yearofexperience_numbers.contains(Yr_exp))
			{
				yearofexperience_list_obj.get(i).click();
				System.out.println("Selected year of experiance is "+Yr_exp);
			}
		}
				
	}
	
	//DATE PICKER
	public static void sendkeys_date(String date)
	{		
		POM_Automation_Practise.textbox_date(Constant_Toolsqa.driver).sendKeys(date);
		
		System.out.println("enter date is "+date);
		// This will scroll down the page 
		   JavascriptExecutor js = (JavascriptExecutor)Constant_Toolsqa.driver;
		   js.executeScript("scroll(0,350)");
		   
		
	}
	
	//
	
	//SELECT AUTOMATION TOOL
	public static void select_automation_tool(String AT_Tools)
	{
		//List<WebElement> automation_list_menu_obj = POM_Automation_Practise.wb_checkbox_automation_tool(Constant_Toolsqa.driver);
		
		List<WebElement> automation_list_menu_obj = Constant_Toolsqa.driver.findElements(By.xpath(".//input[@name='tool']"));
		int automation_list_menu_count = automation_list_menu_obj.size();
		//To print the names of automation tools
		for(int i=0;i<automation_list_menu_count;i++)
		{
			String automation_names = automation_list_menu_obj.get(i).getAttribute("value").toString().trim();
			System.out.println("Automation tools names are: "+automation_names);
			if(automation_names.contains(AT_Tools))
			{
				automation_list_menu_obj.get(i).click();
				System.out.println("Select Automation Tools is "+AT_Tools);
			}
		}
	}
	
	//SELECT PROFESSION
	public static void select_profession()
	{
		/*List<WebElement> profession_list_obj = POM_Automation_Practise.wb_checkbox_profession(Constant_Toolsqa.driver);
		//List<WebElement> profession_list_obj = Constant_Toolsqa.driver.findElements(By.xpath(".//*[@name='profession']"));
		int profession_count = profession_list_obj.size();
		System.out.println(profession_count);
		//To print the names of profession
		for(int i=0;i<profession_count;i++)
		{
			String profession_names = profession_list_obj.get(i).getAttribute("values").toString().trim();
			System.out.println("Profession names are: "+profession_names);
			if(profession_names.contains("Manual Tester"))
			{
				profession_list_obj.get(i).click();
			}
		}*/
		
		List<WebElement> obj= Constant_Toolsqa.driver.findElements(By.xpath(".//input[@name='profession']"));
		
		System.out.println(obj.size());
		
		
		for(int i=0 ;i<obj.size();i++){
			
			System.out.println(obj.get(i).getAttribute("value"));
		}
		
		obj.get(1).click();
		}
	
	
	//SELECT CONTINENTS
	public static void select_continents() throws Exception
	{
		
		Thread.sleep(3000);
		WebElement Continents_obj = POM_Automation_Practise.select_menu_continents(Constant_Toolsqa.driver);
		Select select_obj= new Select(Continents_obj);
		
		List<WebElement> select_continents_list = select_obj.getOptions();
		
		int continents_list_count = select_continents_list.size();
		
		for(int i=0;i<continents_list_count;i++){
			
			
			String listname = select_continents_list.get(i).getText().toString();
			
			System.out.println(listname);
			
		}
		
	}
	
	//SELECT SELENIUM COMMANDS
	public static void select_selenium_commands()
	{
		List<WebElement> selenium_commands_obj = POM_Automation_Practise.listlink_selenium_commands(Constant_Toolsqa.driver);
		int selenium_commands_count = selenium_commands_obj.size();
		//To print the names of selenium commands
		for(int i=0;i<selenium_commands_count;i++)
		{
			String selenium_commands_names = selenium_commands_obj.get(i).getAttribute("value").toString().trim();
			System.out.println("Selenium Comaands names are "+selenium_commands_names);
			if(selenium_commands_names.contains("selenium_commands_names"))
			{
				selenium_commands_obj.get(i).click();
			}
		}
	}
	
	//CLICK ON SUBMIT BUTTON
	public static void click_on_submit_button()
	{
		POM_Automation_Practise.button_submitbutton(Constant_Toolsqa.driver).click();
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
